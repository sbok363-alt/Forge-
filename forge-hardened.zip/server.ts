import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, FunctionCall } from "@google/genai";
import dotenv from "dotenv";
import { initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import fs from 'fs';
import { fetchUserDocs, fetchUserDoc, createDoc, updateDoc } from './src/lib/firestore-rest';
import { toolDeclarations, executeTool, validatePlanArgs, validateProposalArgs } from './src/lib/server-tools';

dotenv.config();

const firebaseConfig = JSON.parse(fs.readFileSync('./firebase-applet-config.json', 'utf8'));
const adminApp = initializeApp({ projectId: firebaseConfig.projectId });
const adminAuth = getAuth(adminApp);

function getGenAIClient(customApiKey?: string) {
  const key = customApiKey || process.env.GEMINI_API_KEY;
  if (!key) {
    throw new Error("No Gemini API key found. Please activate FORGE Brain Copilot with your Gemini API key.");
  }
  return new GoogleGenAI({
    apiKey: key.trim(),
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  app.post("/api/test-gemini-key", async (req, res) => {
    try {
      const idToken = req.headers.authorization?.split('Bearer ')[1];
      if (!idToken) {
        return res.status(401).json({ success: false, error: "Unauthorized" });
      }
      try {
        await adminAuth.verifyIdToken(idToken);
      } catch (authErr) {
        return res.status(401).json({ success: false, error: "Unauthorized: Invalid ID token" });
      }

      const { apiKey } = req.body;
      // Unlike before, an unauthenticated caller can no longer omit apiKey
      // and have this silently fall back to testing (and burning quota on)
      // the server's own process.env.GEMINI_API_KEY.
      const userSuppliedKey = typeof apiKey === 'string' ? apiKey.trim() : '';
      if (!userSuppliedKey) {
        return res.status(400).json({ success: false, error: "API key is required" });
      }
      if (userSuppliedKey.length > 256) {
        return res.status(400).json({ success: false, error: "API key is not a plausible length" });
      }

      const client = new GoogleGenAI({
        apiKey: userSuppliedKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
      
      let response;
      try {
        response = await client.models.generateContent({
          model: "gemini-flash-latest",
          contents: "ping",
        });
      } catch (e1: any) {
        try {
          response = await client.models.generateContent({
            model: "gemini-3.1-flash-lite",
            contents: "ping",
          });
        } catch (e2: any) {
          response = await client.models.generateContent({
            model: "gemini-3.7-flash",
            contents: "ping",
          });
        }
      }

      res.json({ success: true, text: response.text });
    } catch (err: any) {
      console.error("Test Gemini Key Error:", err);
      res.status(400).json({ 
        success: false, 
        error: err.message || "Failed to validate Gemini API key",
        status: err.status || 400
      });
    }
  });

  app.post("/api/forge-brain", async (req, res) => {
    res.setHeader('Content-Type', 'application/x-ndjson');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    // A client can now abort this request mid-stream in the ordinary course
    // of using the app — Brain.tsx cancels a superseded request whenever
    // the user switches threads or sends a follow-up before the previous
    // one finished (see activeRequestRef in Brain.tsx). That closes the
    // underlying socket out from under whichever res.write()/res.end() call
    // happens next in this handler. Writable streams in Node emit an
    // 'error' event when that happens, and an 'error' event with no
    // listener is one of the few things that crashes the ENTIRE process by
    // default — taking down every other in-flight request for every other
    // user, not just this one. This listener contains that to a normal,
    // logged, per-request event instead.
    res.on('error', (err) => {
      console.warn("forge-brain response stream error (client likely disconnected):", err.message);
    });

    // Separately from the crash-prevention listener above: once we know the
    // client is gone, there's no point starting another Gemini call in the
    // tool-call loop below just to throw the result away — each turn is a
    // real, billed API call. 'close' fires reliably on client disconnect
    // across Node versions (unlike the deprecated req.aborted property), so
    // it's a safe signal to check between turns.
    let clientDisconnected = false;
    req.on('close', () => { clientDisconnected = true; });

    try {
      const { messages, geminiApiKey } = req.body; // Array of { role, content }
      const customKey = (req.headers['x-gemini-api-key'] as string) || geminiApiKey;
      const idToken = req.headers.authorization?.split('Bearer ')[1];
      
      if (!idToken) {
        res.write(JSON.stringify({ type: 'error', error: "Unauthorized: Missing ID token" }) + '\n');
        res.end();
        return;
      }

      // 1. Verify Identity
      let uid;
      try {
        const decodedToken = await adminAuth.verifyIdToken(idToken);
        uid = decodedToken.uid;
      } catch (err) {
        res.write(JSON.stringify({ type: 'error', error: "Unauthorized: Invalid ID token" }) + '\n');
        res.end();
        return;
      }
      
      let ai;
      try {
        ai = getGenAIClient(customKey);
      } catch (keyErr: any) {
        res.write(JSON.stringify({ type: 'error', error: keyErr.message }) + '\n');
        res.end();
        return;
      }
      
      const dbId = firebaseConfig.firestoreDatabaseId || '(default)';
      
      const context = { projectId: firebaseConfig.projectId, dbId, idToken, uid };

      // Server-authoritative autonomy enforcement.
      //
      // req.body.autonomyLevel (sent by the client) is NEVER used as the
      // basis for this decision — the client cannot be trusted to report
      // its own permission level truthfully. Instead we fetch the
      // permissions document ourselves, using the caller's own verified ID
      // token, the same way get_user_profile already does. That means
      // Firestore's ownership rule (userId == auth.uid) is what actually
      // guarantees this is the real, current permission state for THIS uid.
      //
      // Today the app has exactly two tools capable of mutating data
      // (propose_workout_change, create_plan), and both already require the
      // user to explicitly approve the resulting proposal/plan before
      // anything is written — nothing here auto-executes. So the one
      // enforcement distinction that's honest to make right now is:
      // L0_READ_ONLY gets no mutation tools offered to the model at all;
      // every other level gets them, still gated behind that existing
      // human-approval step. A deeper L1/L2/L3 split isn't implemented
      // because the app doesn't have differentiated execution behavior
      // for those levels yet — enforcing a distinction the execution layer
      // doesn't actually have would just be security theater in the other
      // direction.
      const MUTATION_TOOL_NAMES = new Set(['propose_workout_change', 'create_plan']);
      let serverAutonomyLevel = 'L2_GUIDED_AUTONOMY';
      try {
        const permissionsDoc = await fetchUserDoc(firebaseConfig.projectId, dbId, idToken, 'user_permissions', uid);
        if (permissionsDoc?.autonomyLevel) {
          serverAutonomyLevel = permissionsDoc.autonomyLevel;
        }
      } catch (permErr) {
        // If we can't verify permissions, fail closed: treat as read-only
        // rather than silently falling back to a level that grants
        // mutation tools.
        console.warn("Could not fetch user_permissions, defaulting to L0_READ_ONLY for this request:", permErr);
        serverAutonomyLevel = 'L0_READ_ONLY';
      }

      const allowedToolDeclarations = serverAutonomyLevel === 'L0_READ_ONLY'
        ? toolDeclarations.filter(t => !MUTATION_TOOL_NAMES.has(t.name))
        : toolDeclarations;

      const systemInstruction = `You are FORGE Brain, an advanced AI fitness intelligence and copilot. 
You act as a personal coach inside the FORGE gym app, proposing modifications to user workouts with optimistic concurrency control (OCC).
IMPORTANT RULES:
1. NEVER fabricate or guess user statistics, PRs, or workout data. ALWAYS use the provided tools (get_workouts, get_recent_workouts, get_exercise_history, get_progression_analysis) to retrieve actual data.
2. PROGRESSION & TARGETS: When the user asks "Why am I not progressing on bench?", "How has my squat progressed?", "Should I increase my weight?", or "What should I do today?", ALWAYS call 'get_progression_analysis' or 'get_exercise_history' to examine their real deterministic trajectory (e1RM trend, RIR, session volume, and recommended targets).
3. FITNESS DATA IS AUTHORITATIVE: If the user claims a PR in chat but the database shows otherwise, gently correct them based on recorded history.
4. PROPOSING WORKOUT CHANGES: When the user asks to modify a workout, add progressive overload, reschedule, change exercises, or optimize sets, ALWAYS use the 'propose_workout_change' tool. Ensure you fetch the target workout first with get_workouts to get its exact current 'version' (this is the baseVersion) and current sets.
5. OCC BASE VERSION: You MUST supply the exact current version of the workout as baseVersion.
6. SUMMARY: Provide a concise, professional summary explaining the physiological or progression rationale (e.g., "Progressive Overload: +2.5kg on Barbell Bench Press (80kg -> 82.5kg) & +2 reps on Lateral Raises").
7. PROGRESSION HEURISTICS: Strong performance -> suggest 2.5-5kg load increase or +1-2 reps. Stable -> maintain load, strive for rep PR. Regression or fatigue -> maintain or slight volume taper.
8. Keep answers practical, direct, evidence-based, concise, and actionable. Avoid generic motivational spam, excessive emojis, and NEVER say "As an AI...".`;

      const formattedContents = messages.map((m: any) => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }]
      }));

      let currentContents = [...formattedContents];
      let turnCount = 0;
      const MAX_TURNS = 5; // Prevent infinite loops

      while (turnCount < MAX_TURNS) {
        turnCount++;

        if (clientDisconnected) {
          // The client that would have received this turn's output is
          // gone (superseded by a newer request or the tab was closed) —
          // stop here rather than spending another Gemini call on a
          // response nobody will read.
          return;
        }
        
        let response;
        try {
          response = await ai.models.generateContent({
            model: "gemini-flash-latest",
            contents: currentContents,
            config: {
              systemInstruction: systemInstruction,
              temperature: 0.7,
              tools: [{ functionDeclarations: allowedToolDeclarations }]
            }
          });
        } catch (mErr: any) {
          console.warn("Retrying with fallback model gemini-3.1-flash-lite due to:", mErr.message);
          response = await ai.models.generateContent({
            model: "gemini-3.1-flash-lite",
            contents: currentContents,
            config: {
              systemInstruction: systemInstruction,
              temperature: 0.7,
              tools: [{ functionDeclarations: allowedToolDeclarations }]
            }
          });
        }

        const candidate = response.candidates?.[0];
        if (!candidate) {
          throw new Error("No response from model");
        }

        // Add the model's response to the conversation history
        currentContents.push(candidate.content);

        // Check for function calls
        const functionCalls = response.functionCalls;
        
        if (functionCalls && functionCalls.length > 0) {
          const functionResponses: any[] = [];
          
          for (const call of functionCalls) {
            // Defense in depth: even though L0_READ_ONLY callers were never
            // offered these tool declarations, refuse explicitly if a
            // mutation tool call shows up anyway, rather than relying
            // solely on the model not asking for a tool it wasn't given.
            if (MUTATION_TOOL_NAMES.has(call.name) && serverAutonomyLevel === 'L0_READ_ONLY') {
              functionResponses.push({
                functionResponse: {
                  id: call.id,
                  name: call.name,
                  response: { error: "This account is set to read-only autonomy (L0). Workout modifications are not permitted. Ask the user to change their autonomy level in settings if they want the AI to propose changes." }
                }
              });
              continue;
            }

            // Check if it's a WRITE action or workout change proposal requiring user confirmation
            if (call.name === 'propose_workout_change') {
               const targetId = typeof call.args?.targetEntityId === 'string' ? call.args.targetEntityId : '';

               // The model is allowed to propose changes, but it is NEVER
               // allowed to define concurrency truth. Fetch the live workout
               // (via the user's own ID token, so Firestore's ownership rules
               // enforce that it's actually theirs) and derive baseVersion +
               // beforeState from that live document — not from whatever the
               // model happened to pass in call.args.baseVersion.
               let targetWorkout: any = null;
               try {
                 targetWorkout = targetId ? await fetchUserDoc(firebaseConfig.projectId, dbId, idToken, 'workouts', targetId) : null;
               } catch (fetchErr: any) {
                 functionResponses.push({
                   functionResponse: {
                     id: call.id,
                     name: call.name,
                     response: { error: `Failed to look up target workout: ${fetchErr.message}. Please retry.` }
                   }
                 });
                 continue;
               }

               if (!targetWorkout) {
                 functionResponses.push({
                   functionResponse: {
                     id: call.id,
                     name: call.name,
                     response: { error: `Target workout '${targetId}' was not found, or does not belong to this user. Call get_workouts to find a valid workout ID first.` }
                   }
                 });
                 continue;
               }

               const authoritativeBaseVersion = typeof targetWorkout.version === 'number' ? targetWorkout.version : 0;

               const beforeState = {
                 version: authoritativeBaseVersion,
                 title: targetWorkout.title,
                 scheduledDate: targetWorkout.scheduledDate,
                 status: targetWorkout.status,
                 sets: targetWorkout.sets
               };

               const proposalArgs = {
                 targetEntityId: targetId,
                 baseVersion: authoritativeBaseVersion,
                 summary: call.args?.summary,
                 afterState: call.args?.afterState
               };

               try {
                 validateProposalArgs(proposalArgs);
               } catch (validationErr: any) {
                 functionResponses.push({
                   functionResponse: {
                     id: call.id,
                     name: call.name,
                     response: { error: `Proposal validation failed: ${validationErr.message}` }
                   }
                 });
                 continue;
               }

               const proposal = {
                 id: crypto.randomUUID(),
                 targetEntityType: 'WORKOUT',
                 targetEntityId: targetId,
                 // observedVersion / baseVersion are both server-authoritative,
                 // derived from targetWorkout.version above — never from the model.
                 observedVersion: authoritativeBaseVersion,
                 baseVersion: authoritativeBaseVersion,
                 status: 'PENDING_APPROVAL',
                 summary: proposalArgs.summary,
                 beforeState,
                 afterState: proposalArgs.afterState
               };

               res.write(JSON.stringify({
                 type: 'done',
                 response: candidate.content.parts.find((p: any) => p.text)?.text || "I have prepared a proposed modification for your review. See the diff below.",
                 proposal
               }) + '\n');
               res.end();
               return;
            }

            if (['create_plan', 'modify_plan', 'create_workout', 'modify_workout'].includes(call.name)) {
               if (call.name === 'create_plan' || call.name === 'modify_plan') {
                 try {
                   validatePlanArgs(call.args);
                 } catch (e: any) {
                   functionResponses.push({
                     functionResponse: {
                       id: call.id,
                        name: call.name,
                       response: { error: `Validation failed: ${e.message}. Please fix the plan structure and try again.` }
                     }
                   });
                   continue;
                 }
               }
               // We intercept the write action and return it as a proposed action
               res.write(JSON.stringify({
                 type: 'done',
                 response: candidate.content.parts.find((p: any) => p.text)?.text || "I have prepared a plan for you. Please review it below.",
                 proposedAction: {
                   id: call.id,
                        name: call.name,
                   args: call.args
                 }
               }) + '\n');
               res.end();
               return;
            }

            // Normal READ tool
            res.write(JSON.stringify({ type: 'tool', name: call.name }) + '\n');

            try {
              const result = await executeTool(call.name, call.args, context);
              functionResponses.push({
                functionResponse: {
                  id: call.id,
                        name: call.name,
                  response: result
                }
              });
            } catch (err: any) {
              functionResponses.push({
                functionResponse: {
                  id: call.id,
                        name: call.name,
                  response: { error: err.message }
                }
              });
            }
          }

          // Add the function responses back to the conversation history
          currentContents.push({
            role: 'user',
            parts: functionResponses
          });
          
          // Loop will continue and call generateContent again
        } else {
          // No function calls, we are done
          res.write(JSON.stringify({ type: 'done', response: candidate.content.parts.find((p: any) => p.text)?.text || "" }) + '\n');
          res.end();
          return;
        }
      }

      res.write(JSON.stringify({ type: 'error', error: "Exceeded max tool invocation turns." }) + '\n');
      res.end();
    } catch (error: any) {
      console.error("Gemini/Auth API Error:", error.message);
      res.write(JSON.stringify({ type: 'error', error: error.message || "Failed to generate AI response." }) + '\n');
      res.end();
    }
  });

  app.post("/api/optimize-workout", async (req, res) => {
    try {
      const idToken = req.headers.authorization?.split('Bearer ')[1];
      if (!idToken) return res.status(401).json({ error: "Unauthorized" });
      await adminAuth.verifyIdToken(idToken);

      const { workout, strategy, geminiApiKey } = req.body;
      if (!workout?.id) {
        return res.status(400).json({ error: "workout.id is required" });
      }

      // The client sends its live in-session `sets` (which may include
      // completed-set toggles not yet persisted to Firestore), so we can't
      // just discard it and re-fetch from the DB. Instead, confirm the
      // workout ID actually belongs to this caller — using their own ID
      // token, so Firestore's ownership rules (userId == auth.uid) do the
      // enforcement — before letting the AI operate on the client's data.
      const dbId = firebaseConfig.firestoreDatabaseId || '(default)';
      const ownedWorkout = await fetchUserDoc(firebaseConfig.projectId, dbId, idToken, 'workouts', workout.id);
      if (!ownedWorkout) {
        return res.status(404).json({ error: "Workout not found or not owned by this user" });
      }

      const ai = new GoogleGenAI({ apiKey: geminiApiKey || process.env.GEMINI_API_KEY });

      const prompt = `
        You are a strength and conditioning AI. The user is in the middle of a workout.
        They requested the strategy: ${strategy}.
        
        Workout: ${workout.title}
        Current Sets: ${JSON.stringify(workout.sets)}
        
        If strategy is SWAP_EXERCISE: Find the incomplete sets and replace the exercise with a suitable alternative for the same muscle group. Keep the load reasonable.
        If strategy is MID_SESSION_DELOAD: Find the incomplete sets and reduce the weight by 20% and reps by 2 to reduce fatigue while finishing the session.
        
        Return ONLY a JSON array of WorkoutSetItem objects. Do not wrap in markdown blocks. Just the JSON array.
        Only update sets where completed is false. Keep completed sets exactly the same.
        Every set must have id, exercise, reps, weight, completed (boolean).
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3.1-flash-lite",
        contents: prompt,
        config: {
          temperature: 0.2,
          responseMimeType: "application/json"
        }
      });

      let newSets = workout.sets;
      try {
        if (response.text) {
          const raw = response.text.replace(/```json/g, '').replace(/```/g, '').trim();
          newSets = JSON.parse(raw);
        }
      } catch (e) {
        console.error("Failed to parse AI optimization response:", e);
      }

      res.json({ success: true, sets: newSets });
    } catch (error: any) {
      console.error("Optimization error:", error.message);
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/forge-apply-plan", async (req, res) => {
    try {
      const idToken = req.headers.authorization?.split('Bearer ')[1];
      if (!idToken) return res.status(401).json({ error: "Unauthorized" });
      const decodedToken = await adminAuth.verifyIdToken(idToken);
      const uid = decodedToken.uid;
      const { action } = req.body;
      
      validatePlanArgs(action.args);
      
      const planId = action.args.planId || crypto.randomUUID();
      const plan = {
        id: planId,
        userId: uid,
        name: action.args.name,
        goal: action.args.goal,
        isActive: true,
        days: action.args.days.map((d: any) => ({
          id: crypto.randomUUID(),
          name: d.name,
          exercises: d.exercises.map((e: any) => ({
            id: crypto.randomUUID(),
            exerciseId: e.exerciseId,
            targetSets: e.targetSets,
            targetRepsMin: e.targetRepsMin,
            targetRepsMax: e.targetRepsMax
          }))
        }))
      };
      
      const dbId = firebaseConfig.firestoreDatabaseId || '(default)';
      
      if (action.name === 'modify_plan' && action.args.planId) {
        await updateDoc(firebaseConfig.projectId, dbId, idToken, 'plans', planId, plan);
      } else {
        await createDoc(firebaseConfig.projectId, dbId, idToken, 'plans', planId, plan);
      }
      
      res.json({ success: true, plan });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
