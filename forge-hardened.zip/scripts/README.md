# Manual debug scripts

These are one-off scripts used while wiring up Firebase Admin/Auth/Firestore
during development. They are **not** part of the app or an automated test
suite (see `/tests` for that) — run them manually with `node scripts/<file>.js`
if you ever need to sanity-check Firebase Admin credentials again.

Safe to delete once you're confident the Firebase Admin setup is stable.
