import { create } from 'zustand';
import { Workout, WorkoutExercise, WorkoutSet } from '../types';
import { persist } from 'zustand/middleware';

interface WorkoutState {
  activeWorkout: Workout | null;
  restEndTime: number | null;
  startWorkout: (workout: Workout) => void;
  finishWorkout: () => void;
  setRestTimer: (durationSeconds: number) => void;
  clearRestTimer: () => void;
  updateSet: (exerciseId: string, setId: string, updates: Partial<WorkoutSet>) => void;
  addSet: (exerciseId: string, set: WorkoutSet) => void;
  removeSet: (exerciseId: string, setId: string) => void;
  addExercise: (exercise: WorkoutExercise) => void;
  removeExercise: (exerciseId: string) => void;
}

export const useWorkoutStore = create<WorkoutState>()(
  persist(
    (set) => ({
      activeWorkout: null,
      restEndTime: null,
      startWorkout: (workout) => set({ 
        activeWorkout: {
          ...workout,
          exercises: workout.exercises || []
        }, 
        restEndTime: null 
      }),
      finishWorkout: () => set({ activeWorkout: null, restEndTime: null }),
      setRestTimer: (durationSeconds) => set({ restEndTime: Date.now() + durationSeconds * 1000 }),
      clearRestTimer: () => set({ restEndTime: null }),
      
      updateSet: (exerciseId, setId, updates) => set((state) => {
        if (!state.activeWorkout) return state;
        const currentExercises = state.activeWorkout.exercises || [];
        const exercises = currentExercises.map(ex => {
          if (ex.id !== exerciseId) return ex;
          return {
            ...ex,
            sets: ex.sets.map(s => s.id === setId ? { ...s, ...updates } : s)
          };
        });
        return { activeWorkout: { ...state.activeWorkout, exercises } };
      }),

      addSet: (exerciseId, newSet) => set((state) => {
        if (!state.activeWorkout) return state;
        const currentExercises = state.activeWorkout.exercises || [];
        const exercises = currentExercises.map(ex => {
          if (ex.id !== exerciseId) return ex;
          return { ...ex, sets: [...ex.sets, newSet] };
        });
        return { activeWorkout: { ...state.activeWorkout, exercises } };
      }),

      removeSet: (exerciseId, setId) => set((state) => {
        if (!state.activeWorkout) return state;
        const currentExercises = state.activeWorkout.exercises || [];
        const exercises = currentExercises.map(ex => {
          if (ex.id !== exerciseId) return ex;
          return { ...ex, sets: ex.sets.filter(s => s.id !== setId) };
        });
        return { activeWorkout: { ...state.activeWorkout, exercises } };
      }),

      addExercise: (exercise) => set((state) => {
        if (!state.activeWorkout) return state;
        const currentExercises = state.activeWorkout.exercises || [];
        return { 
          activeWorkout: { 
            ...state.activeWorkout, 
            exercises: [...currentExercises, exercise] 
          } 
        };
      }),

      removeExercise: (exerciseId) => set((state) => {
        if (!state.activeWorkout) return state;
        const currentExercises = state.activeWorkout.exercises || [];
        return { 
          activeWorkout: { 
            ...state.activeWorkout, 
            exercises: currentExercises.filter(ex => ex.id !== exerciseId) 
          } 
        };
      })
    }),
    {
      name: 'forge-active-workout',
    }
  )
);
