// Shared validation logic for a proposed workout "afterState".
//
// This file has NO server-only or browser-only imports, so it can be
// imported from both:
//  - server.ts / src/lib/server-tools.ts (Node, via validateProposalArgs)
//    to validate afterState when the AI creates a proposal, and
//  - src/lib/api.ts (browser, inside executeProposal's transaction)
//    to re-validate afterState immediately before it's ever written to a
//    real workout document.
//
// That second call site is the one that actually matters most: a proposal
// document in Firestore is client-writable (see firestore.rules), so it
// must never be trusted just because it *looks* like something the AI
// tool would have produced. The database is a trust boundary, not the UI
// that happened to write to it.

export const VALID_WORKOUT_STATUSES = ['PLANNED', 'IN_PROGRESS', 'COMPLETED', 'SKIPPED', 'CANCELLED'];

const MAX_WEIGHT = 2000; // kg — implausible above this for any tracked lift
const MAX_REPS = 200;

function isFiniteNonNegativeNumber(n: any): boolean {
  return typeof n === 'number' && Number.isFinite(n) && n >= 0;
}

/**
 * Validates the shape and bounds of a proposed workout "afterState".
 * Throws a descriptive Error on the first problem found. Does not mutate
 * its input.
 */
export function validateWorkoutAfterState(afterState: any): void {
  if (!afterState || typeof afterState !== 'object' || Array.isArray(afterState)) {
    throw new Error("afterState object is required.");
  }

  const { title, scheduledDate, status, sets } = afterState;

  if (!title || typeof title !== 'string' || title.length > 100) {
    throw new Error("afterState.title is required, must be a string, and must be 100 characters or fewer.");
  }
  if (!scheduledDate || typeof scheduledDate !== 'string' || scheduledDate.length > 50) {
    throw new Error("afterState.scheduledDate is required and must be a string.");
  }
  if (status !== undefined && !VALID_WORKOUT_STATUSES.includes(status)) {
    throw new Error(`afterState.status must be one of: ${VALID_WORKOUT_STATUSES.join(', ')}.`);
  }
  if (!Array.isArray(sets) || sets.length === 0) {
    throw new Error("afterState.sets must be a non-empty array.");
  }
  if (sets.length > 100) {
    throw new Error("afterState.sets has an implausible number of entries.");
  }

  for (let i = 0; i < sets.length; i++) {
    const s = sets[i];
    if (!s || typeof s !== 'object' || Array.isArray(s)) {
      throw new Error(`afterState.sets[${i}] must be an object.`);
    }
    if (!s.id || typeof s.id !== 'string') {
      throw new Error(`afterState.sets[${i}].id is required and must be a string.`);
    }
    if (!s.exercise || typeof s.exercise !== 'string') {
      throw new Error(`afterState.sets[${i}].exercise is required and must be a string.`);
    }
    if (!isFiniteNonNegativeNumber(s.reps) || s.reps <= 0 || !Number.isInteger(s.reps)) {
      throw new Error(`afterState.sets[${i}].reps must be a positive integer.`);
    }
    if (!isFiniteNonNegativeNumber(s.weight)) {
      throw new Error(`afterState.sets[${i}].weight must be a non-negative finite number.`);
    }
    // Guards against overflow-to-Infinity further downstream (e.g.
    // weight * reps in volume/e1RM calculations) as well as obviously
    // fabricated values, not just NaN/negative inputs.
    if (s.weight > MAX_WEIGHT) {
      throw new Error(`afterState.sets[${i}].weight is implausibly large (max ${MAX_WEIGHT}kg).`);
    }
    if (s.reps > MAX_REPS) {
      throw new Error(`afterState.sets[${i}].reps is implausibly large (max ${MAX_REPS}).`);
    }
  }
}
