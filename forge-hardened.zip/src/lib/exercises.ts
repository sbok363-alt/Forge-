export type MuscleGroup = 'CHEST' | 'BACK' | 'SHOULDERS' | 'LEGS' | 'ARMS' | 'CORE' | 'FULL_BODY';
export type MovementPattern = 'PUSH' | 'PULL' | 'HINGE' | 'SQUAT' | 'LUNGE' | 'CARRY' | 'ISOLATION';

export interface ExerciseDef {
  id: string;
  name: string;
  primaryMuscle: MuscleGroup;
  secondaryMuscles?: MuscleGroup[];
  equipment: 'BARBELL' | 'DUMBBELL' | 'MACHINE' | 'CABLE' | 'BODYWEIGHT' | 'OTHER';
  movementPattern: MovementPattern;
}

export const EXERCISE_DATABASE: ExerciseDef[] = [
  // CHEST
  { id: 'bench_press', name: 'Bench Press', primaryMuscle: 'CHEST', secondaryMuscles: ['SHOULDERS', 'ARMS'], equipment: 'BARBELL', movementPattern: 'PUSH' },
  { id: 'incline_bench_press', name: 'Incline Bench Press', primaryMuscle: 'CHEST', secondaryMuscles: ['SHOULDERS', 'ARMS'], equipment: 'BARBELL', movementPattern: 'PUSH' },
  { id: 'dumbbell_bench_press', name: 'Dumbbell Bench Press', primaryMuscle: 'CHEST', secondaryMuscles: ['SHOULDERS', 'ARMS'], equipment: 'DUMBBELL', movementPattern: 'PUSH' },
  { id: 'incline_dumbbell_press', name: 'Incline Dumbbell Press', primaryMuscle: 'CHEST', secondaryMuscles: ['SHOULDERS', 'ARMS'], equipment: 'DUMBBELL', movementPattern: 'PUSH' },
  { id: 'cable_fly', name: 'Cable Fly', primaryMuscle: 'CHEST', equipment: 'CABLE', movementPattern: 'ISOLATION' },
  { id: 'pec_deck', name: 'Pec Deck', primaryMuscle: 'CHEST', equipment: 'MACHINE', movementPattern: 'ISOLATION' },
  
  // BACK
  { id: 'pull_up', name: 'Pull-Up', primaryMuscle: 'BACK', secondaryMuscles: ['ARMS'], equipment: 'BODYWEIGHT', movementPattern: 'PULL' },
  { id: 'lat_pulldown', name: 'Lat Pulldown', primaryMuscle: 'BACK', secondaryMuscles: ['ARMS'], equipment: 'CABLE', movementPattern: 'PULL' },
  { id: 'seated_cable_row', name: 'Seated Cable Row', primaryMuscle: 'BACK', secondaryMuscles: ['ARMS'], equipment: 'CABLE', movementPattern: 'PULL' },
  { id: 'chest_supported_row', name: 'Chest Supported Row', primaryMuscle: 'BACK', equipment: 'MACHINE', movementPattern: 'PULL' },
  { id: 'barbell_row', name: 'Barbell Row', primaryMuscle: 'BACK', secondaryMuscles: ['ARMS', 'CORE'], equipment: 'BARBELL', movementPattern: 'PULL' },
  { id: 'single_arm_dumbbell_row', name: 'Single Arm Dumbbell Row', primaryMuscle: 'BACK', secondaryMuscles: ['ARMS'], equipment: 'DUMBBELL', movementPattern: 'PULL' },

  // SHOULDERS
  { id: 'overhead_press', name: 'Overhead Press', primaryMuscle: 'SHOULDERS', secondaryMuscles: ['ARMS', 'CORE'], equipment: 'BARBELL', movementPattern: 'PUSH' },
  { id: 'dumbbell_shoulder_press', name: 'Dumbbell Shoulder Press', primaryMuscle: 'SHOULDERS', secondaryMuscles: ['ARMS'], equipment: 'DUMBBELL', movementPattern: 'PUSH' },
  { id: 'lateral_raise', name: 'Lateral Raise', primaryMuscle: 'SHOULDERS', equipment: 'DUMBBELL', movementPattern: 'ISOLATION' },
  { id: 'cable_lateral_raise', name: 'Cable Lateral Raise', primaryMuscle: 'SHOULDERS', equipment: 'CABLE', movementPattern: 'ISOLATION' },
  { id: 'rear_delt_fly', name: 'Rear Delt Fly', primaryMuscle: 'SHOULDERS', equipment: 'MACHINE', movementPattern: 'ISOLATION' },
  { id: 'face_pull', name: 'Face Pull', primaryMuscle: 'SHOULDERS', secondaryMuscles: ['BACK'], equipment: 'CABLE', movementPattern: 'PULL' },

  // LEGS
  { id: 'squat', name: 'Squat', primaryMuscle: 'LEGS', secondaryMuscles: ['CORE'], equipment: 'BARBELL', movementPattern: 'SQUAT' },
  { id: 'leg_press', name: 'Leg Press', primaryMuscle: 'LEGS', equipment: 'MACHINE', movementPattern: 'SQUAT' },
  { id: 'romanian_deadlift', name: 'Romanian Deadlift', primaryMuscle: 'LEGS', secondaryMuscles: ['BACK', 'CORE'], equipment: 'BARBELL', movementPattern: 'HINGE' },
  { id: 'leg_curl', name: 'Leg Curl', primaryMuscle: 'LEGS', equipment: 'MACHINE', movementPattern: 'ISOLATION' },
  { id: 'leg_extension', name: 'Leg Extension', primaryMuscle: 'LEGS', equipment: 'MACHINE', movementPattern: 'ISOLATION' },
  { id: 'calf_raise', name: 'Calf Raise', primaryMuscle: 'LEGS', equipment: 'MACHINE', movementPattern: 'ISOLATION' },

  // ARMS
  { id: 'barbell_curl', name: 'Barbell Curl', primaryMuscle: 'ARMS', equipment: 'BARBELL', movementPattern: 'ISOLATION' },
  { id: 'dumbbell_curl', name: 'Dumbbell Curl', primaryMuscle: 'ARMS', equipment: 'DUMBBELL', movementPattern: 'ISOLATION' },
  { id: 'preacher_curl', name: 'Preacher Curl', primaryMuscle: 'ARMS', equipment: 'MACHINE', movementPattern: 'ISOLATION' },
  { id: 'hammer_curl', name: 'Hammer Curl', primaryMuscle: 'ARMS', equipment: 'DUMBBELL', movementPattern: 'ISOLATION' },
  { id: 'tricep_pushdown', name: 'Tricep Pushdown', primaryMuscle: 'ARMS', equipment: 'CABLE', movementPattern: 'ISOLATION' },
  { id: 'overhead_tricep_extension', name: 'Overhead Tricep Extension', primaryMuscle: 'ARMS', equipment: 'CABLE', movementPattern: 'ISOLATION' },
];

export function getExerciseById(id: string): ExerciseDef | undefined {
  return EXERCISE_DATABASE.find(e => e.id === id);
}
