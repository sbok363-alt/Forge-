import { 
  doc, 
  getDoc, 
  setDoc, 
  serverTimestamp, 
  collection, 
  query, 
  where, 
  getDocs, 
  orderBy, 
  limit as firestoreLimit, 
  deleteDoc, 
  writeBatch,
  runTransaction
} from 'firebase/firestore';
import { db } from './firebase';
import { validateWorkoutAfterState } from './validation';
import { 
  UserPermissions, 
  Proposal, 
  Workout, 
  MutationAuditLog, 
  Thread, 
  ThreadMessage, 
  AutonomyLevel,
  ProposalStatus,
  BodyweightEntry,
  PersonalRecord,
  UserProfile
} from '../types';

// ==========================================
// USER PERMISSIONS
// ==========================================

export async function getUserPermissions(userId: string): Promise<UserPermissions> {
  try {
    const docRef = doc(db, 'user_permissions', userId);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docSnap.data() as UserPermissions;
    }
  } catch (e) {
    console.warn("Could not fetch user_permissions from Firestore, fallback to local:", e);
  }
  
  // Default permissions
  const defaultPermissions: UserPermissions = {
    userId,
    autonomyLevel: 'L2_GUIDED_AUTONOMY',
    permissionEpoch: 1
  };
  
  try {
    await setDoc(doc(db, 'user_permissions', userId), defaultPermissions);
  } catch (err) {
    // Ignore if offline
  }
  
  return defaultPermissions;
}

export async function updateUserPermissions(
  userId: string, 
  autonomyLevel: AutonomyLevel
): Promise<UserPermissions> {
  const current = await getUserPermissions(userId);
  const updated: UserPermissions = {
    userId,
    autonomyLevel,
    permissionEpoch: (current.permissionEpoch || 1) + 1
  };

  try {
    await setDoc(doc(db, 'user_permissions', userId), updated);
  } catch (e) {
    console.warn("Could not update Firestore user_permissions:", e);
  }

  localStorage.setItem(`forge_permissions_${userId}`, JSON.stringify(updated));
  return updated;
}

// ==========================================
// WORKOUTS & OPTIMISTIC CONCURRENCY CONTROL (OCC)
// ==========================================

export async function getWorkouts(userId: string): Promise<Workout[]> {
  try {
    const q = query(
      collection(db, 'workouts'),
      where('userId', '==', userId),
      orderBy('scheduledDate', 'desc')
    );
    const snap = await getDocs(q);
    if (!snap.empty) {
      return snap.docs.map(d => ({ id: d.id, ...d.data() } as Workout));
    }
  } catch (e) {
    console.warn("Firestore query failed for workouts, reading localStorage:", e);
  }

  const local = localStorage.getItem(`forge_workouts_${userId}`);
  if (local) {
    try {
      return JSON.parse(local);
    } catch (e) {}
  }
  return [];
}

export async function getWorkout(workoutId: string, userId: string): Promise<Workout | null> {
  try {
    const docRef = doc(db, 'workouts', workoutId);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return { id: snap.id, ...snap.data() } as Workout;
    }
  } catch (e) {
    console.warn("Could not fetch workout from Firestore:", e);
  }

  const list = await getWorkouts(userId);
  return list.find(w => w.id === workoutId) || null;
}

/**
 * Saves a workout (manual edits, applying an AI optimization, finishing an
 * active session, or the "simulate external device edit" test path — every
 * direct workout write in the app funnels through this one function).
 *
 * Rewritten to use a single Firestore transaction for the same reason
 * executeProposal() was: the previous version read the current version via
 * getWorkout() (which itself silently falls back to a localStorage cache on
 * a Firestore read failure — see that function above), computed
 * resultVersion from that possibly-stale read, then wrote the workout and
 * its audit log entry as two separate, unguarded operations. That meant:
 *  - the OCC baseline could be computed from stale/cached data, and
 *  - a workout write could succeed while its audit log write failed,
 *    silently leaving a real mutation with no audit trail — for an app
 *    whose core selling point IS a trustworthy audit trail, that's a
 *    meaningful gap, not just cosmetic.
 *
 * The workout write is still protected against concurrent-write races even
 * without this change, because firestore.rules independently enforces
 * incoming().version == existing().version + 1 at write time — but wrapping
 * both writes in one transaction additionally gets us an atomic audit log
 * and lets us read the authoritative baseVersion via tx.get() instead of
 * through a cache-fallible helper.
 */
export async function saveWorkout(
  workout: Workout,
  actor: 'USER' | 'AI_BRAIN' | 'SYSTEM_AUTONOMOUS' = 'USER',
  summary: string = 'Updated workout sets and details'
): Promise<Workout> {
  const workoutRef = doc(db, 'workouts', workout.id);
  const auditRef = doc(db, 'mutation_audit_logs', crypto.randomUUID());

  // This is the authoritative write — if the transaction fails (rules
  // rejection, network error, OCC conflict, etc.) it throws, and we must
  // not proceed to update the local cache as though it succeeded. Callers
  // are expected to catch this and surface it to the user rather than
  // silently continuing as if the save worked.
  const updatedWorkout = await runTransaction(db, async (tx): Promise<Workout> => {
    const snap = await tx.get(workoutRef);
    const current = snap.exists() ? ({ id: snap.id, ...snap.data() } as Workout) : null;

    const baseVersion = current ? current.version : 0;
    const resultVersion = baseVersion + 1;

    const nextWorkout: Workout = {
      ...workout,
      version: resultVersion,
      updatedAt: new Date().toISOString()
    };

    tx.set(workoutRef, nextWorkout);

    if (workout.userId) {
      const inverseDelta = current ? {
        title: current.title,
        scheduledDate: current.scheduledDate,
        status: current.status,
        sets: current.sets
      } : { deleted: true };

      tx.set(auditRef, {
        id: auditRef.id,
        mutationId: crypto.randomUUID(),
        userId: workout.userId,
        actor,
        targetEntityType: 'WORKOUT',
        targetEntityId: workout.id,
        baseVersion,
        resultVersion,
        summary,
        inverseDelta,
        createdAt: new Date().toISOString()
      });
    }

    return nextWorkout;
  });

  // Best-effort local cache sync. The transaction has already committed at
  // this point, so a failure here just means the cache is briefly stale,
  // not that we've misrepresented whether the save succeeded.
  if (workout.userId) {
    try {
      const all = await getWorkouts(workout.userId);
      const exists = all.some(w => w.id === workout.id);
      const nextList = exists
        ? all.map(w => w.id === workout.id ? updatedWorkout : w)
        : [updatedWorkout, ...all];
      localStorage.setItem(`forge_workouts_${workout.userId}`, JSON.stringify(nextList));
    } catch (e) {
      console.warn("Workout saved but local cache sync failed:", e);
    }
  }

  return updatedWorkout;
}

// ==========================================
// PROPOSALS MANAGEMENT & OCC EXECUTION
// ==========================================

export async function getProposals(userId: string): Promise<Proposal[]> {
  try {
    const q = query(
      collection(db, 'proposals'),
      where('userId', '==', userId),
      orderBy('createdAt', 'desc')
    );
    const snap = await getDocs(q);
    if (!snap.empty) {
      return snap.docs.map(d => ({ id: d.id, ...d.data() } as Proposal));
    }
  } catch (e) {
    console.warn("Could not fetch proposals from Firestore:", e);
  }

  const local = localStorage.getItem(`forge_proposals_${userId}`);
  if (local) {
    try {
      return JSON.parse(local);
    } catch (e) {}
  }
  return [];
}

export async function createProposal(userId: string, proposal: Omit<Proposal, 'createdAt'>): Promise<Proposal> {
  const newProposal: Proposal = {
    ...proposal,
    createdAt: new Date().toISOString()
  };

  try {
    await setDoc(doc(db, 'proposals', proposal.id), { ...newProposal, userId });
  } catch (e) {
    console.warn("Could not save proposal to Firestore:", e);
  }

  const list = await getProposals(userId);
  const updated = [newProposal, ...list.filter(p => p.id !== proposal.id)];
  localStorage.setItem(`forge_proposals_${userId}`, JSON.stringify(updated));

  return newProposal;
}

type ExecuteProposalTxResult =
  | { kind: 'EXECUTED'; workout: Workout; proposal: Proposal; inverseDelta: Record<string, any> }
  | { kind: 'CONFLICT'; proposal: Proposal; liveVersion: number }
  | { kind: 'ALREADY_PROCESSED'; proposal: Proposal }
  | { kind: 'INVALID_AFTERSTATE'; reason: string }
  | { kind: 'NOT_FOUND' };

/**
 * Executes a workout-modification proposal.
 *
 * This used to be a client-side read -> check -> write sequence, which is
 * NOT atomic: two tabs approving the same proposal (or a double-click) could
 * both pass the OCC version check before either write landed, and Firestore
 * write failures were silently swallowed, leaving the proposal marked
 * EXECUTED and the audit log claiming success even when the workout was
 * never actually updated.
 *
 * Note on ownership: this transaction reads the proposal/workout docs
 * directly by ID rather than through the caller's pre-filtered local list.
 * That's safe because every read/write here still runs under the signed-in
 * user's own Firebase Auth credentials, so firestore.rules' ownership checks
 * (userId == auth.uid) are the actual authorization boundary — if either
 * document doesn't belong to this user, Firestore itself will reject the
 * transaction and we surface that as success: false below.
 *
 * Both problems are fixed by moving the entire read -> verify -> write
 * sequence into a single Firestore transaction:
 *  - The proposal itself is re-read live (not from a possibly-stale local
 *    list) and its status is re-checked, so a proposal can only ever be
 *    executed once, even under concurrent approval attempts.
 *  - The workout's version is re-checked against the proposal's baseVersion
 *    inside the same transaction that writes the update, closing the race.
 *  - If the transaction throws for any reason (permission denied, network
 *    failure, contention retries exhausted), we return success: false and
 *    do NOT touch localStorage or the audit log as if it succeeded.
 */
export async function executeProposal(
  proposalId: string, 
  userId: string,
  actor: 'USER' | 'AI_BRAIN' | 'SYSTEM_AUTONOMOUS' = 'USER'
): Promise<{ success: boolean; workout?: Workout; proposal?: Proposal; error?: string }> {
  const proposalRef = doc(db, 'proposals', proposalId);

  let result: ExecuteProposalTxResult;
  try {
    result = await runTransaction(db, async (tx): Promise<ExecuteProposalTxResult> => {
      const proposalSnap = await tx.get(proposalRef);
      if (!proposalSnap.exists()) {
        return { kind: 'NOT_FOUND' };
      }
      const proposal = { ...(proposalSnap.data() as Proposal), id: proposalSnap.id };

      // Guard against double-approval / two-tab races: only a proposal that
      // is still pending, as of this transaction, may be executed.
      if (proposal.status !== 'PENDING_APPROVAL') {
        return { kind: 'ALREADY_PROCESSED', proposal };
      }

      const workoutRef = doc(db, 'workouts', proposal.targetEntityId);
      const workoutSnap = await tx.get(workoutRef);
      if (!workoutSnap.exists()) {
        return { kind: 'NOT_FOUND' };
      }
      const liveWorkout = { ...(workoutSnap.data() as Workout), id: workoutSnap.id };

      if (liveWorkout.version !== proposal.baseVersion) {
        const conflictProposal: Proposal = {
          ...proposal,
          status: 'REJECTED_CONFLICT',
          reviewedAt: new Date().toISOString()
        };
        tx.set(proposalRef, { ...conflictProposal, userId });
        return { kind: 'CONFLICT', proposal: conflictProposal, liveVersion: liveWorkout.version };
      }

      // The proposal document is client-writable (see firestore.rules), so
      // it must never be trusted just because a proposal usually gets
      // created through the validated AI tool path. This is the actual
      // authoritative mutation boundary — re-validate afterState here,
      // immediately before it's ever applied to a real workout, regardless
      // of how this proposal document came to exist. On failure we leave
      // the proposal untouched (still PENDING_APPROVAL) rather than writing
      // any status change, since we don't want to claim a verdict about a
      // proposal whose content we can't trust.
      try {
        validateWorkoutAfterState(proposal.afterState);
      } catch (validationErr: any) {
        return { kind: 'INVALID_AFTERSTATE', reason: validationErr?.message || 'afterState failed validation.' };
      }

      const updatedWorkout: Workout = {
        ...liveWorkout,
        ...proposal.afterState,
        id: liveWorkout.id,
        userId: liveWorkout.userId,
        version: liveWorkout.version + 1,
        updatedAt: new Date().toISOString()
      };

      const executedProposal: Proposal = {
        ...proposal,
        status: 'EXECUTED',
        reviewedAt: new Date().toISOString()
      };

      tx.set(workoutRef, updatedWorkout);
      tx.set(proposalRef, { ...executedProposal, userId });

      return {
        kind: 'EXECUTED',
        workout: updatedWorkout,
        proposal: executedProposal,
        inverseDelta: {
          title: liveWorkout.title,
          scheduledDate: liveWorkout.scheduledDate,
          status: liveWorkout.status,
          sets: liveWorkout.sets
        }
      };
    });
  } catch (e: any) {
    // The transaction itself failed. This is NOT a success — the caller
    // must be told so, and neither localStorage nor the audit log may be
    // updated as if a mutation happened, because it didn't.
    return { success: false, error: e?.message || "Failed to execute proposal due to a database error." };
  }

  if (result.kind === 'NOT_FOUND') {
    return { success: false, error: "Proposal or target workout not found." };
  }

  if (result.kind === 'INVALID_AFTERSTATE') {
    return { success: false, error: `This proposal contains invalid data and cannot be executed: ${result.reason}` };
  }

  if (result.kind === 'ALREADY_PROCESSED') {
    return {
      success: false,
      proposal: result.proposal,
      error: `This proposal has already been ${result.proposal.status.toLowerCase().replace('_', ' ')} and cannot be executed again.`
    };
  }

  if (result.kind === 'CONFLICT') {
    // Best-effort local cache sync. Firestore is already the committed
    // source of truth for the REJECTED_CONFLICT status at this point, so a
    // failure here just means the cache is briefly stale, not that we've
    // misrepresented whether a mutation happened.
    try {
      const proposals = await getProposals(userId);
      localStorage.setItem(`forge_proposals_${userId}`, JSON.stringify(
        proposals.map(p => p.id === proposalId ? result.proposal : p)
      ));
    } catch (e) {
      console.warn("Could not sync conflicted proposal to local cache:", e);
    }

    return {
      success: false,
      proposal: result.proposal,
      error: `Optimistic Concurrency Conflict: target workout has changed since this proposal was created (was based on v${result.proposal.baseVersion}, now v${result.liveVersion}). Please rebase.`
    };
  }

  // EXECUTED — the transaction has already committed both the workout
  // update and the proposal status change atomically. Everything below is
  // best-effort bookkeeping (audit log, local cache) and its failure does
  // not change the fact that the mutation succeeded.
  try {
    await recordMutationAuditLog({
      id: crypto.randomUUID(),
      mutationId: crypto.randomUUID(),
      userId,
      actor,
      targetEntityType: 'WORKOUT',
      targetEntityId: result.workout.id,
      baseVersion: result.proposal.baseVersion,
      resultVersion: result.workout.version,
      summary: `Executed AI Proposal: ${result.proposal.summary}`,
      inverseDelta: result.inverseDelta,
      createdAt: new Date().toISOString()
    });
  } catch (e) {
    console.warn("Mutation succeeded but audit log write failed:", e);
  }

  try {
    const allWorkouts = await getWorkouts(userId);
    localStorage.setItem(`forge_workouts_${userId}`, JSON.stringify(
      allWorkouts.map(w => w.id === result.workout.id ? result.workout : w)
    ));

    const allProposals = await getProposals(userId);
    localStorage.setItem(`forge_proposals_${userId}`, JSON.stringify(
      allProposals.map(p => p.id === proposalId ? result.proposal : p)
    ));
  } catch (e) {
    console.warn("Mutation succeeded but local cache sync failed:", e);
  }

  return { success: true, workout: result.workout, proposal: result.proposal };
}

export async function discardProposal(proposalId: string, userId: string): Promise<Proposal | null> {
  const proposals = await getProposals(userId);
  const proposal = proposals.find(p => p.id === proposalId);
  if (!proposal) return null;

  const discarded: Proposal = {
    ...proposal,
    status: 'DISCARDED',
    reviewedAt: new Date().toISOString()
  };

  try {
    await setDoc(doc(db, 'proposals', proposal.id), { ...discarded, userId });
  } catch (e) {}

  const nextList = proposals.map(p => p.id === proposal.id ? discarded : p);
  localStorage.setItem(`forge_proposals_${userId}`, JSON.stringify(nextList));

  return discarded;
}

// ==========================================
// MUTATION AUDIT LOGS & REVERSIBLE UNDO
// ==========================================

export async function getMutationAuditLogs(userId: string, targetEntityId?: string): Promise<MutationAuditLog[]> {
  try {
    let q = query(
      collection(db, 'mutation_audit_logs'),
      where('userId', '==', userId),
      orderBy('createdAt', 'desc')
    );
    if (targetEntityId) {
      q = query(
        collection(db, 'mutation_audit_logs'),
        where('userId', '==', userId),
        where('targetEntityId', '==', targetEntityId),
        orderBy('createdAt', 'desc')
      );
    }
    const snap = await getDocs(q);
    if (!snap.empty) {
      return snap.docs.map(d => ({ id: d.id, ...d.data() } as MutationAuditLog));
    }
  } catch (e) {
    console.warn("Could not fetch audit logs from Firestore:", e);
  }

  const local = localStorage.getItem(`forge_audit_logs_${userId}`);
  if (local) {
    try {
      const parsed: MutationAuditLog[] = JSON.parse(local);
      if (targetEntityId) {
        return parsed.filter(l => l.targetEntityId === targetEntityId);
      }
      return parsed;
    } catch (e) {}
  }
  return [];
}

export async function recordMutationAuditLog(log: MutationAuditLog): Promise<void> {
  try {
    await setDoc(doc(db, 'mutation_audit_logs', log.id), log);
  } catch (e) {
    console.warn("Could not record audit log to Firestore:", e);
  }

  if (log.userId) {
    const list = await getMutationAuditLogs(log.userId);
    const updated = [log, ...list.filter(l => l.id !== log.id)];
    localStorage.setItem(`forge_audit_logs_${log.userId}`, JSON.stringify(updated));
  }
}

/**
 * Reverts a workout to its state before a specific mutation, verifying the
 * mutation being undone is the most recent one (a contiguous rollback —
 * you can only undo the latest step, not an arbitrary past one, since
 * undoing an older step could silently discard changes made after it).
 *
 * Previously this read the workout, checked its version, and wrote the
 * restored state as three separate, unguarded steps — including an empty
 * catch (e) {} around the workout write that let a FAILED write still
 * proceed to record a "successfully undid mutation" audit log entry. Same
 * bug, same fix as saveWorkout()/executeProposal() above: the whole
 * read -> verify -> write -> audit sequence now runs inside one Firestore
 * transaction, using tx.get() (never the cache-fallible getWorkout()
 * helper) for the authoritative read.
 */
export async function undoMutation(
  auditLogId: string, 
  userId: string
): Promise<{ success: boolean; workout?: Workout; error?: string }> {
  const logs = await getMutationAuditLogs(userId);
  const log = logs.find(l => l.id === auditLogId);
  if (!log) return { success: false, error: "Audit log entry not found" };

  const workoutRef = doc(db, 'workouts', log.targetEntityId);
  const auditRef = doc(db, 'mutation_audit_logs', crypto.randomUUID());

  type UndoTxResult =
    | { kind: 'RESTORED'; workout: Workout }
    | { kind: 'NON_CONTIGUOUS'; liveVersion: number }
    | { kind: 'NOT_FOUND' };

  let result: UndoTxResult;
  try {
    result = await runTransaction(db, async (tx): Promise<UndoTxResult> => {
      const snap = await tx.get(workoutRef);
      if (!snap.exists()) {
        return { kind: 'NOT_FOUND' };
      }
      const workout = { id: snap.id, ...(snap.data() as Workout) };

      // Contiguous OCC check: verify workout is currently at resultVersion.
      // Re-checked here against the live document, not the possibly-stale
      // `logs` list fetched above, so a concurrent mutation between that
      // fetch and this transaction is still caught.
      if (workout.version !== log.resultVersion) {
        return { kind: 'NON_CONTIGUOUS', liveVersion: workout.version };
      }

      const restoredWorkout: Workout = {
        ...workout,
        ...log.inverseDelta,
        id: workout.id,
        userId: workout.userId,
        version: workout.version + 1, // OCC monotonically increases
        updatedAt: new Date().toISOString()
      };

      tx.set(workoutRef, restoredWorkout);
      tx.set(auditRef, {
        id: auditRef.id,
        mutationId: crypto.randomUUID(),
        userId,
        actor: 'USER',
        targetEntityType: 'WORKOUT',
        targetEntityId: workout.id,
        baseVersion: workout.version,
        resultVersion: restoredWorkout.version,
        summary: `Undid mutation (${log.summary}) — restored state from v${log.baseVersion}`,
        inverseDelta: {
          title: workout.title,
          scheduledDate: workout.scheduledDate,
          status: workout.status,
          sets: workout.sets
        },
        createdAt: new Date().toISOString()
      });

      return { kind: 'RESTORED', workout: restoredWorkout };
    });
  } catch (e: any) {
    return { success: false, error: e?.message || "Failed to undo mutation due to a database error." };
  }

  if (result.kind === 'NOT_FOUND') {
    return { success: false, error: "Target workout not found" };
  }
  if (result.kind === 'NON_CONTIGUOUS') {
    return {
      success: false,
      error: `Non-contiguous rollback rejected: Workout is currently at v${result.liveVersion}, but this mutation resulted in v${log.resultVersion}. You can only undo the latest contiguous step.`
    };
  }

  // Best-effort local cache sync — the transaction has already committed.
  try {
    const allWorkouts = await getWorkouts(userId);
    localStorage.setItem(`forge_workouts_${userId}`, JSON.stringify(
      allWorkouts.map(w => w.id === result.workout.id ? result.workout : w)
    ));
  } catch (e) {
    console.warn("Undo succeeded but local cache sync failed:", e);
  }

  return { success: true, workout: result.workout };
}

// ==========================================
// THREADS & COPILOT CHATS
// ==========================================

export async function getThreads(userId: string): Promise<Thread[]> {
  try {
    const q = query(
      collection(db, 'threads'),
      where('userId', '==', userId),
      orderBy('updatedAt', 'desc')
    );
    const snap = await getDocs(q);
    if (!snap.empty) {
      return snap.docs.map(d => ({ id: d.id, ...d.data() } as Thread));
    }
  } catch (e) {
    console.warn("Could not fetch threads from Firestore:", e);
  }

  const local = localStorage.getItem(`forge_threads_${userId}`);
  if (local) {
    try {
      return JSON.parse(local);
    } catch (e) {}
  }
  return [];
}

export async function createThread(userId: string, title: string, targetWorkoutId?: string): Promise<Thread> {
  const newThread: Thread = {
    id: crypto.randomUUID(),
    userId,
    title,
    status: 'ACTIVE',
    targetWorkoutId,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    messages: [
      {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: `Hi! I'm FORGE Brain, your AI fitness copilot. I can inspect your training logs, evaluate progressive overload, and formulate structured proposals for you to review and approve with Optimistic Concurrency Control (OCC). What would you like to work on?`,
        timestamp: new Date().toISOString()
      }
    ]
  };

  try {
    await setDoc(doc(db, 'threads', newThread.id), newThread);
  } catch (e) {}

  const threads = await getThreads(userId);
  localStorage.setItem(`forge_threads_${userId}`, JSON.stringify([newThread, ...threads]));
  return newThread;
}

export async function saveThread(thread: Thread): Promise<void> {
  try {
    await setDoc(doc(db, 'threads', thread.id), thread);
  } catch (e) {}

  const threads = await getThreads(thread.userId);
  const updated = threads.some(t => t.id === thread.id)
    ? threads.map(t => t.id === thread.id ? thread : t)
    : [thread, ...threads];
  localStorage.setItem(`forge_threads_${thread.userId}`, JSON.stringify(updated));
}

// ==========================================
// COMPATIBILITY & ANALYTICS EXPORTS
// ==========================================

export async function getRecentWorkouts(userId: string, limitCount: number = 10): Promise<any[]> {
  const workouts = await getWorkouts(userId);
  return workouts.slice(0, limitCount).map(w => ({
    ...w,
    name: w.title,
    startedAt: new Date(w.scheduledDate).getTime(),
    completedAt: new Date(w.scheduledDate).getTime() + 3600000,
    totalVolume: (w.sets || []).reduce((sum, s) => sum + (s.weight * s.reps), 0),
    exercises: (w.sets || []).map(s => ({
      id: s.id,
      exerciseId: s.exercise.toLowerCase().replace(/\s+/g, '-'),
      sets: [{ id: s.id, weight: s.weight, reps: s.reps, completed: true }]
    }))
  }));
}

export async function getBodyweight(userId: string): Promise<BodyweightEntry[]> {
  try {
    const q = query(collection(db, 'bodyweight'), where('userId', '==', userId), orderBy('date', 'desc'));
    const snap = await getDocs(q);
    if (!snap.empty) {
      return snap.docs.map(d => ({ id: d.id, ...d.data() } as BodyweightEntry));
    }
  } catch (e) {}
  const local = localStorage.getItem(`forge_bw_${userId}`);
  return local ? JSON.parse(local) : [
    { id: 'bw1', userId, weight: 78.5, date: Date.now() - 86400000 * 3 },
    { id: 'bw2', userId, weight: 78.2, date: Date.now() - 86400000 * 7 }
  ];
}

export async function saveBodyweight(entry: BodyweightEntry): Promise<void> {
  try {
    await setDoc(doc(db, 'bodyweight', entry.id), entry);
  } catch (e) {}
  const all = await getBodyweight(entry.userId);
  localStorage.setItem(`forge_bw_${entry.userId}`, JSON.stringify([entry, ...all]));
}

export async function getPlans(userId: string): Promise<any[]> {
  try {
    const q = query(collection(db, 'plans'), where('userId', '==', userId));
    const snap = await getDocs(q);
    if (!snap.empty) return snap.docs.map(d => ({ id: d.id, ...d.data() }));
  } catch (e) {}
  const local = localStorage.getItem(`forge_plans_${userId}`);
  return local ? JSON.parse(local) : [];
}

export async function savePlan(plan: any): Promise<void> {
  try {
    await setDoc(doc(db, 'plans', plan.id), plan);
  } catch (e) {}
  const all = await getPlans(plan.userId);
  localStorage.setItem(`forge_plans_${plan.userId}`, JSON.stringify([plan, ...all.filter(p => p.id !== plan.id)]));
}

export async function deletePlan(planId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'plans', planId));
  } catch (e) {}
}

export async function getUserProfile(userId: string): Promise<UserProfile | null> {
  try {
    const snap = await getDoc(doc(db, 'users', userId));
    if (snap.exists()) return snap.data() as UserProfile;
  } catch (e) {}
  return { userId, name: 'Athlete', experience: 'intermediate', createdAt: Date.now() };
}

export async function saveUserProfile(profile: UserProfile): Promise<void> {
  try {
    await setDoc(doc(db, 'users', profile.userId), profile);
  } catch (e) {}
}

export async function getPersonalRecords(userId: string): Promise<PersonalRecord[]> {
  try {
    const q = query(collection(db, 'personal_records'), where('userId', '==', userId));
    const snap = await getDocs(q);
    if (!snap.empty) return snap.docs.map(d => ({ id: d.id, ...d.data() } as PersonalRecord));
  } catch (e) {}
  return [];
}

export async function getPreviousPerformance(userId: string, exerciseId: string): Promise<any | null> {
  const workouts = await getRecentWorkouts(userId, 30);
  const normId = exerciseId.toLowerCase().replace(/[-_\s]+/g, '');
  
  for (const w of workouts) {
    if (w.status !== 'COMPLETED' && w.status !== 'completed') continue;

    // Check exercises array
    if (w.exercises && Array.isArray(w.exercises)) {
      const match = w.exercises.find((e: any) => {
        const eId = (e.exerciseId || '').toLowerCase().replace(/[-_\s]+/g, '');
        return eId === normId || eId.includes(normId) || normId.includes(eId);
      });
      if (match) return w;
    }

    // Check flat sets array
    if (w.sets && Array.isArray(w.sets)) {
      const match = w.sets.find((s: any) => {
        const sEx = (s.exercise || '').toLowerCase().replace(/[-_\s]+/g, '');
        return sEx === normId || sEx.includes(normId) || normId.includes(sEx);
      });
      if (match) return w;
    }
  }
  return null;
}

export async function savePersonalRecord(record: PersonalRecord): Promise<void> {
  try {
    await setDoc(doc(db, 'personal_records', record.id), record);
  } catch (e) {}
}

// ==========================================
// SEED INITIAL DEMO DATA
// ==========================================

export async function seedForgeData(userId: string): Promise<void> {
  const today = new Date();
  const dateStr = today.toISOString().split('T')[0];
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];
  const nextDay = new Date(today);
  nextDay.setDate(nextDay.getDate() + 3);
  const nextDayStr = nextDay.toISOString().split('T')[0];

  const initialWorkouts: Workout[] = [
    {
      id: `w_upper_${userId}`,
      userId,
      title: 'Upper Body Power & Hypertrophy',
      scheduledDate: dateStr,
      status: 'PLANNED',
      version: 1,
      sets: [
        { id: 's1', exercise: 'Barbell Bench Press', reps: 8, weight: 80, completed: false },
        { id: 's2', exercise: 'Barbell Bench Press', reps: 8, weight: 80, completed: false },
        { id: 's3', exercise: 'Barbell Bench Press', reps: 8, weight: 80, completed: false },
        { id: 's4', exercise: 'Incline Dumbbell Press', reps: 10, weight: 28, completed: false },
        { id: 's5', exercise: 'Incline Dumbbell Press', reps: 10, weight: 28, completed: false },
        { id: 's6', exercise: 'Barbell Bent Over Row', reps: 8, weight: 75, completed: false },
        { id: 's7', exercise: 'Barbell Bent Over Row', reps: 8, weight: 75, completed: false },
        { id: 's8', exercise: 'Lateral Raises', reps: 15, weight: 12, completed: false },
        { id: 's9', exercise: 'Tricep Rope Pushdown', reps: 12, weight: 25, completed: false }
      ],
      updatedAt: new Date().toISOString()
    },
    {
      id: `w_lower_${userId}`,
      userId,
      title: 'Lower Body Strength & Quads',
      scheduledDate: tomorrowStr,
      status: 'PLANNED',
      version: 1,
      sets: [
        { id: 'l1', exercise: 'Barbell Squat', reps: 6, weight: 110, completed: false },
        { id: 'l2', exercise: 'Barbell Squat', reps: 6, weight: 110, completed: false },
        { id: 'l3', exercise: 'Barbell Squat', reps: 6, weight: 110, completed: false },
        { id: 'l4', exercise: 'Romanian Deadlift', reps: 8, weight: 95, completed: false },
        { id: 'l5', exercise: 'Romanian Deadlift', reps: 8, weight: 95, completed: false },
        { id: 'l6', exercise: 'Leg Press', reps: 12, weight: 160, completed: false },
        { id: 'l7', exercise: 'Standing Calf Raise', reps: 15, weight: 60, completed: false }
      ],
      updatedAt: new Date().toISOString()
    },
    {
      id: `w_pull_${userId}`,
      userId,
      title: 'Pull & Posterior Chain',
      scheduledDate: nextDayStr,
      status: 'PLANNED',
      version: 1,
      sets: [
        { id: 'p1', exercise: 'Deadlift', reps: 5, weight: 140, completed: false },
        { id: 'p2', exercise: 'Deadlift', reps: 5, weight: 140, completed: false },
        { id: 'p3', exercise: 'Lat Pulldown', reps: 10, weight: 65, completed: false },
        { id: 'p4', exercise: 'Seated Cable Row', reps: 10, weight: 60, completed: false },
        { id: 'p5', exercise: 'Incline Dumbbell Curl', reps: 12, weight: 14, completed: false },
        { id: 'p6', exercise: 'Face Pulls', reps: 15, weight: 20, completed: false }
      ],
      updatedAt: new Date().toISOString()
    }
  ];

  for (const w of initialWorkouts) {
    try {
      await setDoc(doc(db, 'workouts', w.id), w);
    } catch (e) {}
  }
  localStorage.setItem(`forge_workouts_${userId}`, JSON.stringify(initialWorkouts));

  // Seed default thread
  const threadId = `th_seed_${userId}`;
  const seedProposal: Proposal = {
    id: `prop_seed_${userId}`,
    threadId,
    targetEntityType: 'WORKOUT',
    targetEntityId: initialWorkouts[0].id,
    baseVersion: 1,
    status: 'PENDING_APPROVAL',
    summary: 'Progressive Overload: +2.5kg on Bench Press (80kg -> 82.5kg) & +1 set on Lateral Raises for shoulder volume ramp',
    beforeState: {
      title: initialWorkouts[0].title,
      scheduledDate: initialWorkouts[0].scheduledDate,
      status: initialWorkouts[0].status,
      sets: initialWorkouts[0].sets
    },
    afterState: {
      title: initialWorkouts[0].title,
      scheduledDate: initialWorkouts[0].scheduledDate,
      status: initialWorkouts[0].status,
      sets: [
        { id: 's1', exercise: 'Barbell Bench Press', reps: 8, weight: 82.5, completed: false },
        { id: 's2', exercise: 'Barbell Bench Press', reps: 8, weight: 82.5, completed: false },
        { id: 's3', exercise: 'Barbell Bench Press', reps: 8, weight: 82.5, completed: false },
        { id: 's4', exercise: 'Incline Dumbbell Press', reps: 10, weight: 28, completed: false },
        { id: 's5', exercise: 'Incline Dumbbell Press', reps: 10, weight: 28, completed: false },
        { id: 's6', exercise: 'Barbell Bent Over Row', reps: 8, weight: 75, completed: false },
        { id: 's7', exercise: 'Barbell Bent Over Row', reps: 8, weight: 75, completed: false },
        { id: 's8', exercise: 'Lateral Raises', reps: 15, weight: 12, completed: false },
        { id: 's8_b', exercise: 'Lateral Raises', reps: 15, weight: 12, completed: false },
        { id: 's9', exercise: 'Tricep Rope Pushdown', reps: 12, weight: 25, completed: false }
      ]
    },
    createdAt: new Date().toISOString()
  };

  try {
    await setDoc(doc(db, 'proposals', seedProposal.id), { ...seedProposal, userId });
  } catch (e) {}
  localStorage.setItem(`forge_proposals_${userId}`, JSON.stringify([seedProposal]));

  const seedThread: Thread = {
    id: threadId,
    userId,
    title: 'Upper Body Progressive Overload Audit',
    status: 'ACTIVE',
    targetWorkoutId: initialWorkouts[0].id,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    messages: [
      {
        id: 'm1',
        role: 'user',
        content: 'Can you analyze my upper body workout and recommend progressive overload adjustments?',
        timestamp: new Date(Date.now() - 300000).toISOString()
      },
      {
        id: 'm2',
        role: 'assistant',
        content: 'I reviewed your Upper Body session. You completed all 3 sets of 8 reps at 80kg on Bench Press comfortably last session. Based on your current recovery profile, I propose increasing Bench Press to 82.5kg (+2.5kg overload) and adding a 2nd hypertrophy set of Lateral Raises. Review the proposed diff below:',
        timestamp: new Date().toISOString(),
        proposalId: seedProposal.id,
        proposal: seedProposal
      }
    ]
  };

  try {
    await setDoc(doc(db, 'threads', seedThread.id), seedThread);
  } catch (e) {}
  localStorage.setItem(`forge_threads_${userId}`, JSON.stringify([seedThread]));

  // Seed default User Permissions
  const permissions: UserPermissions = {
    userId,
    autonomyLevel: 'L2_GUIDED_AUTONOMY',
    permissionEpoch: 1
  };
  try {
    await setDoc(doc(db, 'user_permissions', userId), permissions);
  } catch (e) {}

  // Record initial seed mutation audit log
  await recordMutationAuditLog({
    id: `log_seed_${userId}`,
    mutationId: crypto.randomUUID(),
    userId,
    actor: 'SYSTEM_AUTONOMOUS',
    targetEntityType: 'WORKOUT',
    targetEntityId: initialWorkouts[0].id,
    baseVersion: 0,
    resultVersion: 1,
    summary: 'Initialized base workout routine (Upper Body Power & Hypertrophy)',
    inverseDelta: { deleted: true },
    createdAt: new Date().toISOString()
  });
}
