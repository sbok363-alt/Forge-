import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Workout, WorkoutSetItem, ProgressionReport } from '../types';
import { saveWorkout, getWorkouts } from '../lib/api';
import { analyzeExerciseProgression } from '../lib/progression';
import { useAuthStore } from '../store/useAuthStore';
import { Button } from './ui/Button';
import { Input } from './ui/Input';
import { OCCVersionBadge } from './OCCVersionBadge';
import { useGeminiStore } from '../store/useGeminiStore';
import { 
  X, 
  Plus, 
  Trash2, 
  Save, 
  Sparkles, 
  History, 
  AlertTriangle, 
  Calendar, 
  CheckCircle2,
  TrendingUp,
  Zap,
  RotateCcw,
  Layers,
  ArrowRight,
  MessageSquare,
  LineChart,
  Check,
  Brain as BrainIcon,
  Loader2,
  ChevronRight,
  Clock,
  Pencil
} from 'lucide-react';
import { cn } from '../lib/utils';

import { WorkoutCelebration } from './WorkoutCelebration';
import { ExerciseHistorySheet } from './ExerciseHistorySheet';

interface WorkoutDetailModalProps {
  workout: Workout;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updated: Workout) => void;
  onOpenBrain: (workout: Workout) => void;
  onOpenAudit: (workout: Workout) => void;
}

type OptimizationStrategy = 'OVERLOAD' | 'VOLUME' | 'DELOAD' | 'CUSTOM_AI' | 'SWAP_EXERCISE' | 'MID_SESSION_DELOAD';

export function WorkoutDetailModal({
  workout,
  isOpen,
  onClose,
  onSave,
  onOpenBrain,
  onOpenAudit
}: WorkoutDetailModalProps) {
  if (!isOpen) return null;

  const { status: geminiStatus, apiKey: geminiApiKey, openModal: openBYOKModal } = useGeminiStore();
  const { user } = useAuthStore();
  const [title, setTitle] = useState(workout.title);
  const [scheduledDate, setScheduledDate] = useState(workout.scheduledDate);
  const [isEditMode, setIsEditMode] = useState(false);
  const [sets, setSets] = useState<WorkoutSetItem[]>(workout.sets || []);
  const [saving, setSaving] = useState(false);
  const [simulatingConflict, setSimulatingConflict] = useState(false);
  const [allUserWorkouts, setAllUserWorkouts] = useState<Workout[]>([]);
  const [activeRestTimer, setActiveRestTimer] = useState<number | null>(null);
  const [showCelebration, setShowCelebration] = useState(false);
  const [duration, setDuration] = useState(() => {
    if (workout.startedAt) {
      return Math.floor((Date.now() - workout.startedAt) / 1000);
    }
    return 0;
  });
  const [exerciseNotes, setExerciseNotes] = useState<Record<string, string>>(workout.exerciseNotes || {});
  const [openNotes, setOpenNotes] = useState<Record<string, boolean>>({});
  const [activeExerciseHistory, setActiveExerciseHistory] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    const startMs = workout.startedAt || Date.now();
    setDuration(Math.floor((Date.now() - startMs) / 1000));
    const interval = setInterval(() => {
      setDuration(Math.floor((Date.now() - startMs) / 1000));
    }, 1000);
    return () => clearInterval(interval);
  }, [isOpen, workout.startedAt]);

  const formatDuration = (totalSeconds: number) => {
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;
    if (h > 0) {
      return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    }
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const triggerRestCompleteAlert = useCallback(() => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const playBeep = (timeOffset: number) => {
        const osc = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, audioCtx.currentTime + timeOffset);
        osc.frequency.exponentialRampToValueAtTime(400, audioCtx.currentTime + timeOffset + 0.2);
        
        gainNode.gain.setValueAtTime(0.5, audioCtx.currentTime + timeOffset);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + timeOffset + 0.2);
        
        osc.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        
        osc.start(audioCtx.currentTime + timeOffset);
        osc.stop(audioCtx.currentTime + timeOffset + 0.2);
      };
      playBeep(0);
      playBeep(0.3);
    } catch (e) {
      console.warn("AudioContext failed", e);
    }

    if ('vibrate' in navigator) {
      navigator.vibrate([200, 100, 200]);
    }

    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification("Rest Over! Time for your next set 💪");
    }
  }, []);

  // Fetch all workouts to calculate history and pre-fill
  useEffect(() => {
    if (!user) return;
    getWorkouts(user.uid).then(w => setAllUserWorkouts(w));
  }, [user]);

  // Compute progression reports for each unique exercise
  const progressionReports = useMemo(() => {
    const map: Record<string, ProgressionReport> = {};
    if (!allUserWorkouts.length) return map;
    
    const exerciseIds = new Set(sets.map(s => s.exercise).filter((e): e is string => Boolean(e)));
    exerciseIds.forEach((exId: string) => {
      map[exId] = analyzeExerciseProgression(allUserWorkouts, exId);
    });
    return map;
  }, [sets, allUserWorkouts]);

  // Pre-fill next session targets when launching a scheduled workout
  useEffect(() => {
    if (workout.status === 'PLANNED' && allUserWorkouts.length > 0 && sets.length > 0) {
      let needsUpdate = false;
      const updatedSets = sets.map(s => {
        if (s.weight > 0 && s.reps > 0) return s; // Already filled
        const rep = progressionReports[s.exercise];
        if (!rep || rep.state === 'INSUFFICIENT_DATA' || !rep.lastPerformance) return s;
        
        needsUpdate = true;
        const last = rep.lastPerformance;
        let newWeight = last.weight;
        let newReps = last.reps;

        if (rep.state === 'PROGRESSING' && (last.rir !== undefined && last.rir >= 2)) {
          newWeight += 2.5;
        }

        return { ...s, weight: newWeight, reps: newReps };
      });

      if (needsUpdate) {
        setSets(updatedSets);
      }
    }
  }, [workout.status, allUserWorkouts.length, progressionReports]);

  // AI Optimizer View State
  const [showOptimizer, setShowOptimizer] = useState(false);
  const [strategy, setStrategy] = useState<OptimizationStrategy>('OVERLOAD');
  const [optimizing, setOptimizing] = useState(false);
  const [proposedSets, setProposedSets] = useState<WorkoutSetItem[] | null>(null);
  const [optSummary, setOptSummary] = useState<string>('');
  const [optRationales, setOptRationales] = useState<string[]>([]);

  const handleUpdateSet = (index: number, field: keyof WorkoutSetItem, value: any) => {
    const updated = [...sets];
    updated[index] = { ...updated[index], [field]: value };
    setSets(updated);
  };

  const handleAddSet = () => {
    const lastSet = sets[sets.length - 1];
    const newSet: WorkoutSetItem = {
      id: crypto.randomUUID(),
      exercise: lastSet ? lastSet.exercise : 'Barbell Bench Press',
      reps: lastSet ? lastSet.reps : 10,
      weight: lastSet ? lastSet.weight : 60,
      completed: false
    };
    setSets([...sets, newSet]);
  };

  const handleAddSetForExercise = (exerciseName: string) => {
    const exerciseSets = sets.filter(s => s.exercise === exerciseName);
    const lastSet = exerciseSets.length > 0 ? exerciseSets[exerciseSets.length - 1] : null;
    const newSet: WorkoutSetItem = {
      id: crypto.randomUUID(),
      exercise: exerciseName,
      reps: lastSet ? lastSet.reps : 10,
      weight: lastSet ? lastSet.weight : 0,
      completed: false
    };
    
    // Insert the new set after the last set of this exercise
    const newSets = [...sets];
    const lastIndex = newSets.map(s => s.exercise).lastIndexOf(exerciseName);
    if (lastIndex >= 0) {
      newSets.splice(lastIndex + 1, 0, newSet);
      setSets(newSets);
    } else {
      setSets([...sets, newSet]);
    }
  };

  const handleRemoveSet = (index: number) => {
    setSets(sets.filter((_, i) => i !== index));
  };

  const handleToggleSet = (index: number) => {
    if (isEditMode) return;
    
    const isCompleted = !sets[index].completed;
    handleUpdateSet(index, 'completed', isCompleted);
    if (isCompleted) {
      setActiveRestTimer(90); // 90s default rest
      if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
      }
    } else {
      setActiveRestTimer(null);
    }
  };

  useEffect(() => {
    if (activeRestTimer === null || activeRestTimer === 0) return;
    const interval = setInterval(() => {
      setActiveRestTimer(prev => {
        if (prev === null) {
          clearInterval(interval);
          return null;
        }
        if (prev <= 1) {
          clearInterval(interval);
          triggerRestCompleteAlert();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [activeRestTimer === null || activeRestTimer === 0, triggerRestCompleteAlert]);

  // Helper to calculate total tonnage (reps * weight)
  const calculateVolume = (setList: WorkoutSetItem[]) => {
    return setList.reduce((acc, s) => acc + ((s.weight || 0) * (s.reps || 0)), 0);
  };

  // Run the Optimization Engine
  const handleRunOptimization = async (chosenStrategy: OptimizationStrategy = strategy) => {
    setStrategy(chosenStrategy);
    setOptimizing(true);
    setShowOptimizer(true);

    // Simulate smart computation / Progressive Overload algorithm
    await new Promise(resolve => setTimeout(resolve, 450));

    let newSets: WorkoutSetItem[] = [];
    let summaryText = '';
    let rationales: string[] = [];

    const isCompound = (name: string) => {
      const lower = name.toLowerCase();
      return lower.includes('bench') || lower.includes('squat') || lower.includes('deadlift') || 
             lower.includes('press') || lower.includes('row') || lower.includes('pull-up') || lower.includes('dip');
    };

    if (chosenStrategy === 'OVERLOAD') {
      newSets = sets.map((s) => {
        const compound = isCompound(s.exercise);
        const weightIncrease = compound ? (s.weight >= 80 ? 5 : 2.5) : (s.weight >= 20 ? 2 : 1);
        const nextWeight = s.weight > 0 ? Number((s.weight + weightIncrease).toFixed(1)) : 0;
        const nextReps = s.weight === 0 ? s.reps + 2 : s.reps;
        return {
          ...s,
          id: crypto.randomUUID(),
          weight: nextWeight,
          reps: nextReps
        };
      });
      summaryText = `Progressive Overload Applied (+2.5kg - +5kg on Compound Movements)`;
      rationales = [
        "Incremented main compound movements by +2.5kg to stimulate mechanical tension.",
        "Maintained prescribed rep ranges to prioritize neuromuscular adaptation.",
        "Increased total tonnage while keeping recovery demands within adaptive limits."
      ];
    } else if (chosenStrategy === 'VOLUME') {
      newSets = sets.map((s) => ({
        ...s,
        id: crypto.randomUUID(),
        reps: s.reps + 2
      }));
      // Add a back-off set for the primary movement
      if (sets.length > 0) {
        const first = sets[0];
        newSets.push({
          id: crypto.randomUUID(),
          exercise: first.exercise,
          weight: Number((first.weight * 0.85).toFixed(1)),
          reps: first.reps + 4,
          completed: false
        });
      }
      summaryText = `Hypertrophy Volume Ramp (+2 Reps & 85% Back-off Set)`;
      rationales = [
        "Added +2 reps per working set to maximize metabolic stress and pump stimulus.",
        "Inserted an 85% back-off set to accumulate additional high-quality effective reps.",
        "Elevated total session volume without excessively increasing peak joint strain."
      ];
    } else if (chosenStrategy === 'DELOAD') {
      newSets = sets.map((s) => ({
        ...s,
        id: crypto.randomUUID(),
        weight: Number((s.weight * 0.65).toFixed(1)),
        reps: Math.min(s.reps, 8)
      }));
      summaryText = `Active Recovery & Deload Tuning (-35% Load, Form Focus)`;
      rationales = [
        "Scaled intensities down to 65% 1RM to dissipate central fatigue.",
        "Capped reps at 8 to avoid proximity to failure and safeguard connective tissue.",
        "Maintained movement patterns to facilitate active recovery and technique refinement."
      ];
    } else if (chosenStrategy === 'SWAP_EXERCISE' || chosenStrategy === 'MID_SESSION_DELOAD') {
      try {
        const token = user ? await user.getIdToken() : '';
        const res = await fetch('/api/optimize-workout', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(token && { 'Authorization': `Bearer ${token}` })
          },
          body: JSON.stringify({ workout: { ...workout, sets }, strategy: chosenStrategy, geminiApiKey })
        });
        const data = await res.json();
        if (data.success && data.sets) {
          newSets = data.sets;
          summaryText = chosenStrategy === 'SWAP_EXERCISE' ? 'Equipment Busy: Exercise Swapped' : 'Low Energy: Mid-Session Deload Applied';
          rationales = [
            "Analyzed remaining incomplete sets using Gemini AI.",
            chosenStrategy === 'SWAP_EXERCISE' ? "Replaced exercise with a biomechanically similar alternative." : "Reduced load by 20% and reps by 2 for remaining sets.",
            "Locked version utilizing OCC for conflict-free state merging."
          ];
        } else {
          throw new Error('API failed');
        }
      } catch (e) {
        // Fallback simulation
        newSets = sets.map(s => s.completed ? s : {
          ...s,
          exercise: chosenStrategy === 'SWAP_EXERCISE' ? `${s.exercise} (Machine/Cable)` : s.exercise,
          weight: chosenStrategy === 'MID_SESSION_DELOAD' ? Number((s.weight * 0.8).toFixed(1)) : s.weight,
          reps: chosenStrategy === 'MID_SESSION_DELOAD' ? Math.max(1, s.reps - 2) : s.reps
        });
        summaryText = chosenStrategy === 'SWAP_EXERCISE' ? 'Exercise Swapped (Offline Fallback)' : 'Mid-Session Deload (Offline Fallback)';
        rationales = ["Applied fallback adjustments.", "Modified incomplete sets only."];
      }
    } else {
      // Custom AI Deep Analysis
      newSets = sets.map((s, idx) => {
        const compound = isCompound(s.exercise);
        return {
          ...s,
          id: crypto.randomUUID(),
          weight: idx === 0 && compound ? Number((s.weight + 2.5).toFixed(1)) : s.weight,
          reps: idx > 0 ? s.reps + 1 : s.reps
        };
      });
      summaryText = `AI Neuromuscular Optimization (Targeted Overload & Intensity Curve)`;
      rationales = [
        "Adjusted lead movement for peak strength stimulus while staggering accessory volume.",
        "Calibrated load distribution based on historical recovery metrics.",
        "Optimized working sets for maximum rate of force development."
      ];
    }

    setProposedSets(newSets);
    setOptSummary(summaryText);
    setOptRationales(rationales);
    setOptimizing(false);
  };

  const handleApplyOptimization = async () => {
    if (!proposedSets) return;
    setSaving(true);
    try {
      const updated: Workout = {
        ...workout,
        title,
        scheduledDate,
        status: isEditMode ? workout.status : 'IN_PROGRESS',
        sets: proposedSets,
        exerciseNotes
      };
      const result = await saveWorkout(updated, 'AI_BRAIN', `FORGE Brain AI Optimization: ${optSummary}`);
      onSave(result);
      onClose();
    } catch (e) {
      console.error("Failed to apply optimization:", e);
    } finally {
      setSaving(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const isCompleting = !isEditMode;
      const newStatus = isCompleting ? 'COMPLETED' : workout.status;
      
      const updated: Workout = {
        ...workout,
        title,
        scheduledDate,
        status: newStatus,
        sets,
        exerciseNotes
      };
      
      const result = await saveWorkout(updated, 'USER', `Manual edit by user on ${title}`);
      
      if (isCompleting) {
        setShowCelebration(true);
        // Do not close immediately, let Celebration modal take over
        onSave(result); // updates the parent state in the background
      } else {
        onSave(result);
        onClose();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setSaving(false);
    }
  };

  const handleSimulateExternalEdit = async () => {
    setSimulatingConflict(true);
    try {
      const simulated: Workout = {
        ...workout,
        title: `${title} (v${workout.version + 1} Ext)`,
        sets: sets.map((s, idx) => idx === 0 ? { ...s, weight: s.weight + 2.5 } : s)
      };
      const result = await saveWorkout(simulated, 'USER', `Simulated external device edit (+2.5kg on set 1)`);
      onSave(result);
    } catch (e) {
      console.error(e);
    } finally {
      setSimulatingConflict(false);
    }
  };

  const currentVol = calculateVolume(sets);
  const proposedVol = proposedSets ? calculateVolume(proposedSets) : currentVol;
  const volDiff = proposedVol - currentVol;
  const volPercent = currentVol > 0 ? ((volDiff / currentVol) * 100).toFixed(1) : '0';

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            key="workout-detail-modal"
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          className="fixed inset-0 z-[60] flex flex-col items-center justify-end bg-background/95 backdrop-blur-md"
        >
          <div className="bg-card w-full h-full sm:h-[95vh] sm:max-w-3xl sm:rounded-t-3xl sm:border sm:border-border sm:border-b-0 shadow-2xl flex flex-col overflow-hidden">

        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-border flex flex-col sm:flex-row sm:items-center justify-between bg-secondary/20 gap-3 shrink-0">
          <div className="flex items-center justify-between w-full sm:w-auto gap-3">
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <Input 
                  value={title} 
                  onChange={(e) => setTitle(e.target.value)}
                  className="font-bold text-base sm:text-lg h-9 sm:h-10 bg-secondary/40 border-border flex-1"
                />
                <OCCVersionBadge 
                  version={workout.version} 
                  onClick={() => onOpenAudit(workout)}
                />
              </div>
              <div className="flex items-center gap-2 sm:gap-3 text-xs text-muted-foreground mt-2">
                <div className="flex items-center gap-1 bg-secondary/40 px-2 py-1 rounded-md border border-border">
                  <Calendar size={12} />
                  <input 
                    type="date" 
                    value={scheduledDate}
                    onChange={(e) => setScheduledDate(e.target.value)}
                    className="bg-transparent border-none text-foreground font-mono text-xs focus:outline-none"
                  />
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-1 sm:hidden shrink-0">
              <Button 
                variant={isEditMode ? "default" : "ghost"} 
                size="icon" 
                onClick={() => setIsEditMode(!isEditMode)}
                title={isEditMode ? "Exit Edit Mode" : "Edit Workout Structure"}
              >
                <Pencil size={18} />
              </Button>
              <Button variant="ghost" size="icon" onClick={onClose}>
                <X size={18} />
              </Button>
            </div>
          </div>
          <div className="hidden sm:flex items-center gap-2 shrink-0">
            <Button 
              variant={isEditMode ? "default" : "outline"} 
              size="sm" 
              onClick={() => setIsEditMode(!isEditMode)}
              className="gap-2"
            >
              <Pencil size={14} />
              {isEditMode ? "Done Editing" : "Edit"}
            </Button>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X size={18} />
            </Button>
          </div>
        </div>

        {/* Action Shortcuts Bar */}
        <div className="px-4 py-2.5 bg-secondary/30 border-b border-border/40 flex items-center justify-between gap-2 flex-wrap shrink-0">
          <div className="flex items-center gap-2 flex-1 sm:flex-none">
            <Button 
              size="sm" 
              variant={showOptimizer ? "secondary" : "default"}
              className={cn(
                "h-8 sm:h-9 text-xs font-semibold flex-1 sm:flex-none gap-1.5 shadow-xs",
                showOptimizer ? "border border-primary/40 text-primary" : "bg-primary text-primary-foreground"
              )}
              onClick={() => {
                if (!showOptimizer) {
                  handleRunOptimization('OVERLOAD');
                } else {
                  setShowOptimizer(false);
                }
              }}
            >
              <Sparkles size={14} className={showOptimizer ? "text-primary" : ""} /> 
              {showOptimizer ? "Manual Set Editor" : "⚡ Optimize Workout"}
            </Button>

            <Button 
              size="sm"
              variant="outline"
              className="h-8 sm:h-9 text-xs gap-1.5 text-muted-foreground hover:text-primary"
              onClick={() => {
                onClose();
                onOpenBrain(workout);
              }}
              title="Open full conversation with FORGE Brain Copilot"
            >
              <BrainIcon size={14} />
              <span className="hidden sm:inline">Brain Copilot</span>
            </Button>
          </div>

          <div className="flex items-center gap-2 flex-1 sm:flex-none justify-end">
            <Button 
              size="sm" 
              variant="outline" 
              className="h-8 sm:h-9 text-xs text-amber-600 dark:text-amber-400 border-amber-500/30 hover:bg-amber-500/10"
              onClick={handleSimulateExternalEdit}
              disabled={simulatingConflict}
              title="Simulates another device editing this workout to demo OCC"
            >
              <AlertTriangle size={13} className="mr-1 shrink-0" />
              <span>{simulatingConflict ? 'Bumping...' : 'Simulate Conflict'}</span>
            </Button>
            
            <Button 
              size="icon" 
              variant="ghost" 
              className="h-8 w-8 sm:h-9 sm:w-9 shrink-0"
              onClick={() => onOpenAudit(workout)}
              title="Mutation Audit History"
            >
              <History size={15} />
            </Button>
          </div>
        </div>

        {/* Modal Body: Either AI Optimizer View or Manual Set Editor */}
        {showOptimizer ? (
          <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1 relative">
            {/* Strategy Selector Chips */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span className="font-semibold text-foreground flex items-center gap-1.5">
                  <Sparkles size={13} className="text-primary" /> Select Optimization Goal:
                </span>
                <span className="font-mono text-[11px]">OCC Target: v{workout.version} → v{workout.version + 1}</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 sm:gap-2">
                {[
                  { id: 'OVERLOAD', label: 'Overload', desc: '+2.5-5kg Load', icon: TrendingUp },
                  { id: 'VOLUME', label: 'Hypertrophy', desc: '+2 Reps & Back-off', icon: Layers },
                  { id: 'DELOAD', label: 'Deload', desc: '-35% Fatigue Reset', icon: RotateCcw },
                  { id: 'CUSTOM_AI', label: 'Deep AI', desc: 'Neural Calibration', icon: BrainIcon }
                ].map(item => {
                  const Icon = item.icon;
                  const active = strategy === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleRunOptimization(item.id as OptimizationStrategy)}
                      disabled={optimizing}
                      className={cn(
                        "p-2.5 rounded-xl text-left border transition-all flex flex-col justify-between gap-1",
                        active 
                          ? "bg-primary/10 border-primary text-primary shadow-xs" 
                          : "bg-secondary/40 border-border/60 hover:bg-secondary text-foreground"
                      )}
                    >
                      <div className="flex items-center justify-between">
                        <Icon size={14} className={active ? "text-primary" : "text-muted-foreground"} />
                        {active && <Check size={12} className="text-primary font-bold" />}
                      </div>
                      <div>
                        <div className="text-xs font-bold leading-tight">{item.label}</div>
                        <div className="text-[10px] text-muted-foreground mt-0.5">{item.desc}</div>
                      </div>
                    </button>
                  );
                })}
              </div>
              
              <div className="grid grid-cols-2 gap-1.5 sm:gap-2 mt-2">
                <button
                  onClick={() => handleRunOptimization('SWAP_EXERCISE')}
                  disabled={optimizing}
                  className="p-2.5 rounded-xl text-left border bg-secondary/40 border-border/60 hover:bg-secondary text-foreground transition-all flex items-center gap-2"
                >
                  <div className="bg-amber-500/20 text-amber-600 p-1.5 rounded-lg shrink-0">
                    <AlertTriangle size={14} />
                  </div>
                  <div>
                    <div className="text-xs font-bold leading-tight">Equipment Busy</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">Swap Exercise via AI</div>
                  </div>
                </button>
                <button
                  onClick={() => handleRunOptimization('MID_SESSION_DELOAD')}
                  disabled={optimizing}
                  className="p-2.5 rounded-xl text-left border bg-secondary/40 border-border/60 hover:bg-secondary text-foreground transition-all flex items-center gap-2"
                >
                  <div className="bg-emerald-500/20 text-emerald-600 p-1.5 rounded-lg shrink-0">
                    <Zap size={14} />
                  </div>
                  <div>
                    <div className="text-xs font-bold leading-tight">Low Energy</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">Deload Current Session</div>
                  </div>
                </button>
              </div>
            </div>

            {/* Optimization Progress or Diff Result */}
            {optimizing ? (
              <div className="p-8 text-center border border-dashed border-primary/30 rounded-2xl bg-primary/5 flex flex-col items-center justify-center gap-2">
                <Loader2 size={24} className="text-primary animate-spin" />
                <span className="text-sm font-semibold text-foreground">Analyzing sets & calculating progressive overload...</span>
                <span className="text-xs text-muted-foreground">Evaluating mechanical tension curves and OCC version lock.</span>
              </div>
            ) : proposedSets ? (
              <div className="space-y-4">
                {/* Summary Banner */}
                <div className="p-3.5 rounded-xl bg-secondary/50 border border-primary/20 space-y-2">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2">
                      <div className="p-1 rounded-md bg-primary/10 text-primary">
                        <Sparkles size={14} />
                      </div>
                      <span className="font-bold text-xs sm:text-sm text-foreground">{optSummary}</span>
                    </div>

                    <div className="flex items-center gap-2 text-xs font-mono">
                      <span className="text-muted-foreground">{currentVol.toLocaleString()}kg</span>
                      <ArrowRight size={12} className="text-primary" />
                      <span className="font-bold text-foreground">{proposedVol.toLocaleString()}kg</span>
                      <span className={cn(
                        "text-[10px] font-bold px-1.5 py-0.5 rounded",
                        volDiff >= 0 ? "bg-emerald-500/10 text-emerald-500" : "bg-blue-500/10 text-blue-500"
                      )}>
                        {volDiff >= 0 ? `+${volPercent}%` : `${volPercent}%`}
                      </span>
                    </div>
                  </div>

                  {/* Physiological Rationales */}
                  <ul className="space-y-1 text-xs text-muted-foreground pt-1 border-t border-border/40">
                    {optRationales.map((r, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <CheckCircle2 size={13} className="text-primary shrink-0 mt-0.5" />
                        <span>{r}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Proposed Sets Diff Preview */}
                <div className="space-y-2">
                  <div className="text-xs font-bold text-muted-foreground uppercase tracking-wider">
                    Proposed Set Breakdown ({proposedSets.length} sets)
                  </div>

                  <div className="space-y-2">
                    {proposedSets.map((pset, idx) => {
                      const orig = sets[idx];
                      const weightDelta = orig ? pset.weight - orig.weight : pset.weight;
                      const repDelta = orig ? pset.reps - orig.reps : pset.reps;
                      const isNewSet = !orig;

                      return (
                        <div 
                          key={pset.id || idx}
                          className="flex items-center justify-between p-2.5 rounded-xl bg-secondary/30 border border-border/50 text-xs"
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <span className="h-6 w-6 rounded-md bg-secondary text-foreground font-bold flex items-center justify-center text-[11px] shrink-0">
                              {idx + 1}
                            </span>
                            <span className="font-semibold text-foreground truncate">{pset.exercise}</span>
                            {isNewSet && (
                              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-accent/20 text-accent uppercase">
                                +Bonus Set
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-3 shrink-0 font-mono">
                            {/* Weight Tag */}
                            <div className="flex items-center gap-1">
                              <span className="font-bold text-foreground">{pset.weight} kg</span>
                              {weightDelta !== 0 && (
                                <span className={cn(
                                  "text-[10px] font-bold",
                                  weightDelta > 0 ? "text-emerald-500" : "text-blue-400"
                                )}>
                                  ({weightDelta > 0 ? `+${weightDelta}` : weightDelta}kg)
                                </span>
                              )}
                            </div>

                            {/* Reps Tag */}
                            <div className="flex items-center gap-1 text-muted-foreground">
                              <span>×</span>
                              <span className="font-bold text-foreground">{pset.reps} reps</span>
                              {repDelta !== 0 && (
                                <span className={cn(
                                  "text-[10px] font-bold",
                                  repDelta > 0 ? "text-emerald-500" : "text-blue-400"
                                )}>
                                  ({repDelta > 0 ? `+${repDelta}` : repDelta})
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            ) : null}
          </div>
        ) : (
          /* Manual Sets Table */
          <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1 relative">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 border-b border-border/40 gap-3">
              <div className="flex gap-4 text-xs font-bold text-muted-foreground uppercase tracking-wider">
                <span className="flex items-center gap-1.5"><Clock size={14} className="text-primary"/> {formatDuration(duration)}</span>
                <span className="flex items-center gap-1.5"><TrendingUp size={14} className="text-primary"/> {calculateVolume(sets).toLocaleString()} kg</span>
                <span className="flex items-center gap-1.5"><CheckCircle2 size={14} className="text-primary"/> {sets.filter(s => s.completed).length}/{sets.length} sets</span>
              </div>
              {isEditMode && (
                <Button size="sm" variant="outline" className="h-8 text-xs font-bold" onClick={handleAddSet}>
                  <Plus size={14} className="mr-1.5" /> Add Exercise
                </Button>
              )}
            </div>

            <div className="space-y-4 pt-1">
              {(() => {
                const groupedSets: { exercise: string; sets: { set: WorkoutSetItem; index: number }[] }[] = [];
                sets.forEach((set, index) => {
                  let group = groupedSets.find(g => g.exercise === set.exercise);
                  if (!group) {
                    group = { exercise: set.exercise, sets: [] };
                    groupedSets.push(group);
                  }
                  group.sets.push({ set, index });
                });

                return groupedSets.map((group) => {
                  const rep = progressionReports[group.exercise];
                  return (
                    <div key={group.exercise} className="rounded-xl border border-border/60 shadow-xs overflow-hidden bg-card">
                      {/* Exercise Header */}
                      <div className="bg-secondary/30 p-3 flex items-center justify-between border-b border-border/60">
                        <div className="flex items-center gap-2">
                          <Input 
                            value={group.exercise}
                            onChange={(e) => {
                              // Update exercise name for all sets in this group
                              group.sets.forEach(({ index }) => {
                                handleUpdateSet(index, 'exercise', e.target.value);
                              });
                            }}
                            className="h-8 text-sm font-bold bg-transparent border-none focus-visible:ring-1 focus-visible:ring-primary w-48 px-2 -ml-2"
                            placeholder="Exercise Name"
                          />
                          {rep && rep.state === 'PROGRESSING' && (
                             <span className="px-1.5 py-0.5 bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 rounded text-[9px] font-bold tracking-wider shrink-0">PROGRESSING</span>
                          )}
                          {rep && rep.state === 'STALLING' && (
                             <span className="px-1.5 py-0.5 bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/20 rounded text-[9px] font-bold tracking-wider shrink-0">STALLING</span>
                          )}
                          {rep && rep.state === 'REGRESSING' && (
                             <span className="px-1.5 py-0.5 bg-rose-500/15 text-rose-600 dark:text-rose-400 border border-rose-500/20 rounded text-[9px] font-bold tracking-wider shrink-0">REGRESSING</span>
                          )}
                          {rep && rep.state === 'INSUFFICIENT_DATA' && (
                             <span className="px-1.5 py-0.5 bg-zinc-500/15 text-zinc-600 dark:text-zinc-400 border border-zinc-500/20 rounded text-[9px] font-bold tracking-wider shrink-0">NEW</span>
                          )}
                        </div>
                        <div className="flex items-center gap-1">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-7 w-7 text-muted-foreground hover:text-primary hover:bg-primary/10"
                            onClick={() => setOpenNotes(prev => ({ ...prev, [group.exercise]: !prev[group.exercise] }))}
                            title="Exercise Notes"
                          >
                            <MessageSquare size={14} className={exerciseNotes[group.exercise] ? "text-primary fill-primary/20" : ""} />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-7 w-7 text-muted-foreground hover:text-primary hover:bg-primary/10"
                            title="History & Analysis"
                            onClick={() => setActiveExerciseHistory(group.exercise)}
                          >
                            <LineChart size={14} />
                          </Button>
                        </div>
                      </div>
                      
                      {/* Exercise Notes Area */}
                      <AnimatePresence>
                        {(openNotes[group.exercise] || exerciseNotes[group.exercise]) && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="overflow-hidden bg-secondary/10 border-b border-border/60"
                          >
                            <div className="p-2">
                              <textarea 
                                value={exerciseNotes[group.exercise] || ''}
                                onChange={(e) => setExerciseNotes(prev => ({ ...prev, [group.exercise]: e.target.value }))}
                                placeholder="Add equipment settings or form cues..."
                                className="w-full bg-transparent border-none focus:outline-none text-xs text-muted-foreground resize-none min-h-[40px] px-2 py-1 placeholder:text-muted-foreground/50"
                              />
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>

                      {/* Sets Table */}
                      <div className="p-2 space-y-1">
                        <div className="grid grid-cols-[30px_1fr_56px_56px_40px_36px_30px] gap-2 px-2 pb-1 text-[9px] font-bold text-muted-foreground uppercase tracking-wider">
                          <div className="text-center">Set</div>
                          <div>Previous</div>
                          <div className="text-center">KG</div>
                          <div className="text-center">Reps</div>
                          <div className="text-center">RIR</div>
                          <div className="text-center">Done</div>
                          <div></div>
                        </div>

                        {group.sets.map(({ set, index }, i) => {
                          const isCompleted = set.completed;
                          const prevSet = rep?.history?.[0]?.sets?.[i];
                          const prevText = prevSet ? `${prevSet.weight}x${prevSet.reps}` : '-';

                          return (
                            <div 
                              key={set.id || index}
                              className={cn(
                                "grid grid-cols-[30px_1fr_56px_56px_40px_36px_30px] gap-2 items-center px-2 py-1 rounded-lg transition-colors duration-300 group",
                                isCompleted ? "bg-emerald-500/10" : "hover:bg-secondary/30"
                              )}
                            >
                              <button 
                                onClick={() => {
                                  const types: ('N' | 'W' | 'D' | 'F')[] = ['N', 'W', 'D', 'F'];
                                  const current = set.setType || 'N';
                                  const next = types[(types.indexOf(current) + 1) % types.length];
                                  handleUpdateSet(index, 'setType', next);
                                }}
                                className={cn(
                                  "text-center text-xs font-mono font-bold w-6 h-6 rounded mx-auto flex items-center justify-center transition-colors cursor-pointer",
                                  set.setType === 'W' ? "bg-amber-500/20 text-amber-600" :
                                  set.setType === 'D' ? "bg-purple-500/20 text-purple-600" :
                                  set.setType === 'F' ? "bg-rose-500/20 text-rose-600" :
                                  "text-muted-foreground hover:bg-secondary/80"
                                )}
                              >
                                {set.setType && set.setType !== 'N' ? set.setType : i + 1}
                              </button>
                              <button 
                                className="text-[11px] text-muted-foreground truncate hover:text-primary transition-colors text-left" 
                                title={prevText}
                                onClick={() => setActiveExerciseHistory(group.exercise)}
                              >
                                {prevText}
                              </button>
                              <Input 
                                type="number"
                                step="0.5"
                                value={set.weight}
                                onChange={(e) => handleUpdateSet(index, 'weight', parseFloat(e.target.value) || 0)}
                                className="h-8 text-xs text-center font-mono bg-background border-border/50 focus-visible:ring-primary px-1"
                              />
                              <Input 
                                type="number"
                                value={set.reps}
                                onChange={(e) => handleUpdateSet(index, 'reps', parseInt(e.target.value) || 0)}
                                className="h-8 text-xs text-center font-mono bg-background border-border/50 focus-visible:ring-primary px-1"
                              />
                              <Input 
                                type="number"
                                min="0" max="10"
                                value={set.rir !== undefined ? set.rir : ''}
                                placeholder="—"
                                onChange={(e) => handleUpdateSet(index, 'rir', e.target.value === '' ? undefined : parseInt(e.target.value))}
                                className="h-8 text-xs text-center font-mono bg-background border-border/50 focus-visible:ring-primary px-1"
                              />
                              <div className="flex justify-center">
                                <motion.button
                                  whileTap={!isEditMode ? { scale: 0.9 } : {}}
                                  animate={isCompleted ? { scale: [1, 1.25, 1] } : {}}
                                  transition={{ duration: 0.3 }}
                                  onClick={() => handleToggleSet(index)}
                                  className={cn(
                                    "flex items-center justify-center h-6 w-6 rounded border transition-colors",
                                    isEditMode ? "opacity-50 cursor-not-allowed grayscale" : "cursor-pointer",
                                    isCompleted 
                                      ? "bg-emerald-500 text-white border-emerald-600" 
                                      : "bg-secondary text-muted-foreground border-border hover:bg-secondary/80 hover:border-primary/50"
                                  )}
                                  disabled={isEditMode}
                                >
                                  {isCompleted ? <Check size={12} strokeWidth={3} /> : null}
                                </motion.button>
                              </div>
                              {isEditMode ? (
                                <Button 
                                  size="icon" 
                                  variant="ghost" 
                                  className="h-6 w-6 text-muted-foreground hover:text-destructive hover:bg-destructive/10 shrink-0 mx-auto transition-opacity"
                                  onClick={() => handleRemoveSet(index)}
                                >
                                  <Trash2 size={12} />
                                </Button>
                              ) : (
                                <div className="w-6" /> // spacer
                              )}
                            </div>
                          );
                        })}
                        
                        {isEditMode && (
                          <div className="pt-2 pb-1 px-2">
                            <Button 
                              size="sm" 
                              variant="ghost" 
                              className="h-7 text-[11px] font-semibold text-primary hover:bg-primary/10 w-full"
                              onClick={() => handleAddSetForExercise(group.exercise)}
                            >
                              <Plus size={12} className="mr-1.5" /> Add Set
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                });
              })()}

              {sets.length === 0 && (
                <div className="text-center py-12 text-muted-foreground text-sm border border-dashed border-border rounded-xl bg-secondary/20">
                  No sets configured. Click "Add Set" or click "⚡ Optimize Workout" to generate sets.
                </div>
              )}
            </div>
          </div>
        )}

        {/* Floating Rest Timer */}
        <AnimatePresence>
          {activeRestTimer !== null && (
            <motion.div
              key="floating-rest-timer"
              initial={{ opacity: 0, y: 50, x: '-50%' }}
              animate={{ opacity: 1, y: 0, x: '-50%' }}
              exit={{ opacity: 0, y: 50, x: '-50%' }}
              className={cn(
                "absolute bottom-20 left-1/2 z-50 px-4 py-2.5 rounded-full shadow-2xl flex items-center gap-4 font-mono font-bold border backdrop-blur-xl transition-all duration-500",
                activeRestTimer === 0 
                  ? "bg-rose-600 text-white border-rose-400 shadow-[0_0_30px_rgba(225,29,72,0.6)] animate-pulse" 
                  : "bg-primary text-primary-foreground border-primary-foreground/20"
              )}
            >
              <div className="flex items-center gap-2">
                <Clock size={18} className={activeRestTimer > 0 ? "animate-pulse" : ""} />
                <span className="text-lg">
                  {activeRestTimer === 0 ? "0:00" : `${Math.floor(activeRestTimer / 60)}:${(activeRestTimer % 60).toString().padStart(2, '0')}`}
                </span>
              </div>
              <div className={cn("flex items-center gap-1.5 border-l pl-3", activeRestTimer === 0 ? "border-white/20" : "border-primary-foreground/20")}>
                <button 
                  onClick={() => setActiveRestTimer(Math.max(0, activeRestTimer - 15))}
                  className={cn("px-2 py-1 rounded-md text-xs transition-colors", activeRestTimer === 0 ? "hover:bg-white/20" : "hover:bg-primary-foreground/20")}
                >
                  -15s
                </button>
                <button 
                  onClick={() => setActiveRestTimer(activeRestTimer === 0 ? 15 : activeRestTimer + 15)}
                  className={cn("px-2 py-1 rounded-md text-xs transition-colors", activeRestTimer === 0 ? "hover:bg-white/20" : "hover:bg-primary-foreground/20")}
                >
                  +15s
                </button>
                <button 
                  onClick={() => setActiveRestTimer(null)}
                  className={cn("ml-1 rounded-full p-1.5 transition-colors", activeRestTimer === 0 ? "hover:bg-white/20" : "hover:bg-primary-foreground/20")}
                >
                  <X size={16} />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Footer */}
        <div className="p-3 sm:p-4 border-t border-border bg-secondary/30 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="text-[11px] text-muted-foreground font-mono font-medium text-center sm:text-left w-full sm:w-auto">
            OCC Mutation: <span className="font-bold text-foreground">v{workout.version} → v{workout.version + 1}</span>
          </div>

          <div className="flex gap-2 w-full sm:w-auto">
            {showOptimizer ? (
              <>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="flex-1 sm:flex-none h-9 text-xs" 
                  onClick={() => setShowOptimizer(false)}
                >
                  Back to Sets
                </Button>
                <Button 
                  size="sm" 
                  className="flex-1 sm:flex-none h-9 text-xs font-bold gap-1.5 bg-primary text-primary-foreground shadow-xs" 
                  onClick={handleApplyOptimization} 
                  disabled={saving || !proposedSets || optimizing}
                >
                  <Check size={14} />
                  {saving ? 'Applying...' : 'Apply Optimization'}
                </Button>
              </>
            ) : (
              <>
                <Button variant="outline" size="sm" className="flex-1 sm:flex-none h-9 text-xs" onClick={onClose}>Cancel</Button>
                <Button 
                  size="sm" 
                  className={cn(
                    "flex-1 sm:flex-none h-9 text-xs font-bold gap-1.5 text-white",
                    isEditMode ? "bg-primary hover:bg-primary/90" : "bg-emerald-600 hover:bg-emerald-700"
                  )} 
                  onClick={handleSave} 
                  disabled={saving}
                >
                  {isEditMode ? <Save size={14} /> : <CheckCircle2 size={14} />}
                  {saving ? 'Saving...' : (isEditMode ? 'Save Changes' : 'Finish Workout')}
                </Button>
              </>
            )}
          </div>
        </div>
          </div>
        </motion.div>
      )}
      </AnimatePresence>

      <AnimatePresence>
        {activeExerciseHistory && (
          <ExerciseHistorySheet
            exercise={activeExerciseHistory}
            report={progressionReports[activeExerciseHistory]}
            onClose={() => setActiveExerciseHistory(null)}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showCelebration && (
          <WorkoutCelebration 
            workout={{...workout, sets}} 
            onClose={() => {
              setShowCelebration(false);
              onClose();
            }} 
          />
        )}
      </AnimatePresence>
    </>
  );
}

