import { createContext, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { useAuthStore } from '../store/useAuthStore';
import { useWorkoutStore } from '../store/useWorkoutStore';
import React from 'react';

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const setUser = useAuthStore((state) => state.setUser);
  const setLoading = useAuthStore((state) => state.setLoading);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      // useWorkoutStore persists the active workout to localStorage under a
      // single global key (not scoped per-user) so it survives a page
      // reload mid-workout. That means it can otherwise leak across
      // different people signing into the same browser/device: if the
      // persisted active workout doesn't belong to whoever is now
      // authenticated (including "nobody", right after sign-out), discard
      // it. Checking the workout's own userId — rather than trying to track
      // auth transitions over time in a separate marker — also correctly
      // discards any data that may have already leaked before this check
      // existed, since it doesn't depend on having seen the transition
      // happen.
      const cachedWorkout = useWorkoutStore.getState().activeWorkout;
      if (cachedWorkout && cachedWorkout.userId !== user?.uid) {
        useWorkoutStore.getState().finishWorkout();
      }

      setUser(user);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [setUser, setLoading]);

  return <>{children}</>;
}
