import React from 'react';
import { Button } from '../components/ui/Button';
import { Card, CardContent } from '../components/ui/Card';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { Dumbbell } from 'lucide-react';

export default function Auth() {
  const handleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error("Login failed", error);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-sm">
        <CardContent className="pt-8 pb-8 flex flex-col items-center text-center space-y-6">
          <div className="h-16 w-16 bg-primary/10 text-primary rounded-2xl flex items-center justify-center">
            <Dumbbell size={32} />
          </div>
          
          <div className="space-y-2">
            <h1 className="text-3xl font-display font-bold tracking-tight">FORGE</h1>
            <p className="text-muted-foreground text-sm">Your AI-powered fitness intelligence.</p>
          </div>

          <Button size="lg" className="w-full" onClick={handleLogin}>
            Continue with Google
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
