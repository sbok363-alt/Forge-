import React, { useState, useEffect, useRef } from 'react';
import { useAuthStore } from '../store/useAuthStore';
import { 
  Thread, 
  ThreadMessage, 
  Proposal, 
  Workout, 
  UserPermissions, 
  AutonomyLevel 
} from '../types';
import { 
  getThreads, 
  createThread, 
  saveThread, 
  getWorkouts, 
  getWorkout,
  getUserPermissions, 
  updateUserPermissions,
  executeProposal,
  discardProposal,
  createProposal,
  seedForgeData
} from '../lib/api';
import { ProposalDiffCard } from '../components/ProposalDiffCard';
import { AutonomyBadge } from '../components/AutonomyBadge';
import { AutonomyModal } from '../components/AutonomyModal';
import { OCCVersionBadge } from '../components/OCCVersionBadge';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Card, CardContent } from '../components/ui/Card';
import { 
  Brain as BrainIcon, 
  Send, 
  Plus, 
  Sparkles, 
  MessageSquare, 
  Layers, 
  ChevronDown, 
  Settings2,
  RefreshCw,
  Dumbbell,
  CheckCircle2,
  History,
  Info
} from 'lucide-react';
import { useLocation } from 'react-router-dom';
import { cn } from '../lib/utils';
import { useGeminiStore } from '../store/useGeminiStore';

export default function Brain() {
  const { user } = useAuthStore();
  const location = useLocation();
  
  const [threads, setThreads] = useState<Thread[]>([]);
  const [activeThread, setActiveThread] = useState<Thread | null>(null);
  const [workouts, setWorkouts] = useState<Workout[]>([]);
  const [permissions, setPermissions] = useState<UserPermissions>({
    userId: user?.uid || '',
    autonomyLevel: 'L2_GUIDED_AUTONOMY',
    permissionEpoch: 1
  });
  
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [toolStatus, setToolStatus] = useState<string | null>(null);
  const [isAutonomyModalOpen, setIsAutonomyModalOpen] = useState(false);
  const [showThreadList, setShowThreadList] = useState(false);
  const { apiKey: geminiApiKey, openModal: openBYOKModal } = useGeminiStore();
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const autoPromptRef = useRef<string | null>(null);

  // Initial load
  useEffect(() => {
    if (!user) return;

    const loadData = async () => {
      const perms = await getUserPermissions(user.uid);
      setPermissions(perms);

      const wList = await getWorkouts(user.uid);
      setWorkouts(wList);

      const tList = await getThreads(user.uid);
      setThreads(tList);

      // Check if navigated with a specific target workout
      const stateTargetWorkoutId = (location.state as any)?.targetWorkoutId;
      const stateAutoPrompt = (location.state as any)?.autoPrompt;
      let threadToActivate: Thread | null = null;

      if (stateTargetWorkoutId) {
        // Find or create thread for this workout
        const existing = tList.find(t => t.targetWorkoutId === stateTargetWorkoutId && t.status === 'ACTIVE');
        if (existing) {
          setActiveThread(existing);
          threadToActivate = existing;
        } else {
          const targetW = wList.find(w => w.id === stateTargetWorkoutId);
          const newT = await createThread(
            user.uid, 
            `Optimize: ${targetW?.title || 'Workout'}`, 
            stateTargetWorkoutId
          );
          setThreads(prev => [newT, ...prev]);
          setActiveThread(newT);
          threadToActivate = newT;
        }
      } else if (tList.length > 0) {
        setActiveThread(tList[0]);
        threadToActivate = tList[0];
      } else {
        // Seed initial data if totally empty
        await seedForgeData(user.uid);
        const seededWorkouts = await getWorkouts(user.uid);
        const seededThreads = await getThreads(user.uid);
        setWorkouts(seededWorkouts);
        setThreads(seededThreads);
        if (seededThreads.length > 0) {
          setActiveThread(seededThreads[0]);
          threadToActivate = seededThreads[0];
        }
      }

      // If autoPrompt was provided and not triggered yet for this navigation
      if (stateAutoPrompt && threadToActivate) {
        const promptKey = `${stateTargetWorkoutId || 'general'}-${stateAutoPrompt}`;
        if (autoPromptRef.current !== promptKey) {
          autoPromptRef.current = promptKey;
          setTimeout(() => {
            handleSend(stateAutoPrompt, threadToActivate!);
          }, 150);
        }
      }
    };

    loadData();
  }, [user, location.state]);

  useEffect(() => {
    scrollToBottom();
  }, [activeThread?.messages, toolStatus, loading]);

  const refreshWorkouts = async () => {
    if (!user) return;
    const wList = await getWorkouts(user.uid);
    setWorkouts(wList);
  };

  const handleNewThread = async () => {
    if (!user) return;
    const newT = await createThread(user.uid, `Session #${threads.length + 1}`);
    setThreads(prev => [newT, ...prev]);
    setActiveThread(newT);
    setShowThreadList(false);
  };

  const handleUpdateAutonomy = async (level: AutonomyLevel) => {
    if (!user) return;
    const updated = await updateUserPermissions(user.uid, level);
    setPermissions(updated);
  };

  // Tracks the currently-authoritative in-flight request. A new call to
  // handleSend() replaces this — aborting whatever was previously running —
  // so at most one request's result is ever allowed to touch shared state
  // (activeThread/threads/Firestore). See handleSend()'s closing comment
  // for the full race this prevents.
  const activeRequestRef = useRef<{ id: number; controller: AbortController } | null>(null);

  const handleSend = async (customPrompt?: string, customThread?: Thread) => {
    const thread = customThread || activeThread;
    const textToSend = customPrompt || input;
    if (!textToSend.trim() || !user || !thread) return;

    // Supersede any previous request BEFORE doing anything else. This must
    // happen synchronously, in the same tick as the optimistic UI update
    // below — that ordering is what guarantees myRequestId is unique and
    // strictly increasing even if two invocations somehow land back-to-back
    // (e.g. the 150ms-deferred autoPrompt effect firing right as the user
    // manually sends a message; two browser tabs don't share this ref, but
    // each tab's own overlapping calls are fully covered by it).
    activeRequestRef.current?.controller.abort();
    const myRequestId = (activeRequestRef.current?.id ?? 0) + 1;
    const controller = new AbortController();
    activeRequestRef.current = { id: myRequestId, controller };
    const isStale = () => activeRequestRef.current?.id !== myRequestId;

    const userMessage: ThreadMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      content: textToSend.trim(),
      timestamp: new Date().toISOString()
    };

    const updatedMessages = [...thread.messages, userMessage];
    const updatedThread: Thread = {
      ...thread,
      messages: updatedMessages,
      updatedAt: new Date().toISOString()
    };

    setActiveThread(updatedThread);
    setThreads(prev => prev.map(t => t.id === updatedThread.id ? updatedThread : t));
    setInput('');
    setLoading(true);
    setToolStatus(null);
    await saveThread(updatedThread);

    try {
      const idToken = await user.getIdToken();
      
      // Send chat history and current target workout context
      const messagesPayload = updatedMessages.slice(-10).map(m => ({
        role: m.role,
        content: m.content
      }));

      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${idToken}`
      };
      if (geminiApiKey) {
        headers['x-gemini-api-key'] = geminiApiKey;
      }

      const res = await fetch('/api/forge-brain', {
        method: 'POST',
        headers,
        signal: controller.signal,
        body: JSON.stringify({
          messages: messagesPayload,
          targetWorkoutId: thread.targetWorkoutId,
          autonomyLevel: permissions.autonomyLevel,
          geminiApiKey: geminiApiKey || undefined
        })
      });

      if (!res.ok) throw new Error("Failed to connect to FORGE Brain");
      if (!res.body) throw new Error("No stream returned");

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        // A newer request superseded this one while we were mid-stream.
        // Stop reading and cancel the underlying connection rather than
        // continuing to receive (and silently discard) tokens nobody will
        // see — the abort() call above already requested this, but a
        // chunk can still land in the brief window before the network
        // layer honors it, so this check is what actually stops us from
        // acting on it.
        if (isStale()) {
          try { await reader.cancel(); } catch {}
          return;
        }

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (!line.trim()) continue;
          try {
            const data = JSON.parse(line);

            if (isStale()) continue;

            if (data.type === 'tool') {
              const toolMap: Record<string, string> = {
                get_user_profile: "Reading user profile & autonomy settings...",
                get_workouts: "Inspecting workout schedules & OCC versions...",
                get_recent_workouts: "Analyzing recent training history...",
                get_exercise_history: "Reviewing progressive overload logs...",
                get_progress: "Evaluating consistency and volume...",
                get_personal_records: "Checking 1RM thresholds..."
              };
              setToolStatus(toolMap[data.name] || `Analyzing via ${data.name}...`);
            } else if (data.type === 'done') {
              setToolStatus(null);
              
              let proposalObj: Proposal | undefined = undefined;
              if (data.proposal) {
                // Save proposal to Firestore & local
                proposalObj = await createProposal(user.uid, {
                  id: data.proposal.id || crypto.randomUUID(),
                  threadId: thread.id,
                  targetEntityType: 'WORKOUT',
                  targetEntityId: data.proposal.targetEntityId,
                  baseVersion: data.proposal.baseVersion,
                  observedVersion: data.proposal.observedVersion,
                  status: 'PENDING_APPROVAL',
                  summary: data.proposal.summary,
                  beforeState: data.proposal.beforeState,
                  afterState: data.proposal.afterState
                });
              }

              // Re-check after the above awaits (createProposal/saveThread
              // do real network round-trips, so a lot can change while
              // we're mid-await) — we still want that proposal correctly
              // persisted to Firestore even if stale (it's real data the
              // server generated), we just must not let a stale response
              // overwrite the currently-active thread's UI state.
              if (isStale()) continue;

              const assistantMessage: ThreadMessage = {
                id: crypto.randomUUID(),
                role: 'assistant',
                content: data.response || "I have formulated a recommendation for you.",
                timestamp: new Date().toISOString(),
                proposalId: proposalObj?.id,
                proposal: proposalObj
              };

              const finalThread: Thread = {
                ...updatedThread,
                messages: [...updatedMessages, assistantMessage],
                updatedAt: new Date().toISOString()
              };

              setActiveThread(finalThread);
              setThreads(prev => prev.map(t => t.id === finalThread.id ? finalThread : t));
              await saveThread(finalThread);
            } else if (data.type === 'error') {
              throw new Error(data.error);
            }
          } catch (e) {
            console.error("Error parsing stream line:", line, e);
          }
        }
      }
    } catch (err: any) {
      // We aborted this ourselves because a newer request superseded it —
      // this is not a real failure, so don't surface a scary error message
      // for what the user experiences as "I sent a different message."
      if (err?.name === 'AbortError') return;
      if (isStale()) return;

      console.error("FORGE Brain error:", err);
      const errorMessage: ThreadMessage = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: `I encountered an issue analyzing your training: ${err.message || 'Please try again'}.`,
        timestamp: new Date().toISOString()
      };
      const errorThread = {
        ...updatedThread,
        messages: [...updatedMessages, errorMessage]
      };
      setActiveThread(errorThread);
      await saveThread(errorThread);
    } finally {
      // Only the still-current request may clear the loading indicator.
      // Without this check, an old request's finally block can run AFTER a
      // new request has already set loading=true, incorrectly hiding the
      // spinner while the new request is genuinely still in flight.
      if (!isStale()) {
        setLoading(false);
        setToolStatus(null);
      }
    }
  };

  // ---------------------------------------------------------------------
  // Why this exists (the race handleSend's requestId/AbortController guard
  // prevents): loading=true disables the Input/Send button/quick-prompt
  // chips, so a same-tab double-send via those controls is already
  // impossible today. But nothing gates thread-switching (clicking a
  // different thread in the sidebar while a request for the current one is
  // still streaming works fine even while loading=true), and the
  // navigation-triggered auto-prompt effect runs on a 150ms setTimeout that
  // isn't gated by loading either. So: open thread A, ask something, switch
  // to thread B before A responds — without the guard above, A's response
  // arrives later and calls setActiveThread(finalThread)/saveThread using A's
  // closed-over updatedThread, silently snapping the UI back to thread A
  // (and persisting that) even though the user has since moved on to B.
  // Two browser tabs on the SAME thread hit an equivalent version of this,
  // just via Firestore's last-write-wins on saveThread() instead of local
  // React state. The fix makes each new handleSend() call cancel whatever
  // request preceded it and marks every shared-state mutation with a
  // request ID check, so only the most recently-initiated request's result
  // is ever allowed to win.
  // ---------------------------------------------------------------------

  const handleApproveProposal = async (proposalId: string) => {
    if (!user) return;
    const res = await executeProposal(proposalId, user.uid, 'USER');
    
    if (res.success && res.workout) {
      await refreshWorkouts();
      // Update proposal state in thread
      if (activeThread) {
        const updatedMsgs = activeThread.messages.map(m => {
          if (m.proposal?.id === proposalId) {
            return {
              ...m,
              proposal: res.proposal
            };
          }
          return m;
        });

        // Append system confirmation
        updatedMsgs.push({
          id: crypto.randomUUID(),
          role: 'system',
          content: `✓ Proposal executed cleanly with Optimistic Concurrency Control. ${res.workout.title} updated to OCC version v${res.workout.version}. Mutation recorded in audit trail with reversible inverse delta.`,
          timestamp: new Date().toISOString()
        });

        const updatedT = { ...activeThread, messages: updatedMsgs };
        setActiveThread(updatedT);
        await saveThread(updatedT);
      }
    } else {
      throw new Error(res.error || "Failed to execute proposal");
    }
  };

  const handleDiscardProposal = async (proposalId: string) => {
    if (!user) return;
    const discarded = await discardProposal(proposalId, user.uid);
    if (activeThread) {
      const updatedMsgs = activeThread.messages.map(m => {
        if (m.proposal?.id === proposalId) {
          return {
            ...m,
            proposal: { ...m.proposal, status: 'DISCARDED' } as Proposal
          };
        }
        return m;
      });
      const updatedT = { ...activeThread, messages: updatedMsgs };
      setActiveThread(updatedT);
      await saveThread(updatedT);
    }
  };

  const handleRebaseProposal = (proposal: Proposal) => {
    const targetW = workouts.find(w => w.id === proposal.targetEntityId);
    handleSend(`Please re-evaluate and rebase your recommendations for ${targetW?.title || 'this workout'} against its current live state at v${targetW?.version || proposal.baseVersion + 1}.`);
  };

  const targetWorkout = activeThread?.targetWorkoutId 
    ? workouts.find(w => w.id === activeThread.targetWorkoutId) 
    : workouts[0];

  const quickPrompts = [
    {
      label: "⚡ Progressive Overload",
      text: targetWorkout 
        ? `Analyze "${targetWorkout.title}" (currently at OCC v${targetWorkout.version}) and propose progressive overload adjustments to weights and sets.` 
        : "Analyze my scheduled workouts and propose progressive overload increments."
    },
    {
      label: "📈 Volume Ramp",
      text: "Propose adding an extra accessory set to target upper chest and lateral deltoids."
    },
    {
      label: "🔄 Shift Schedule",
      text: "Propose shifting my next workout by +1 day for optimal muscular recovery."
    },
    {
      label: "🛡️ Check Plateaus",
      text: "Audit my recent performance data and advise if any lifts are showing a potential plateau."
    }
  ];

  return (
    <div className="flex flex-col h-full min-h-0 flex-1 overflow-hidden w-full max-w-5xl mx-auto">
      {/* Top Header Bar */}
      <header className="mb-1.5 sm:mb-3 flex items-center justify-between gap-2 sm:gap-3 pb-1.5 sm:pb-3 border-b border-border/60 shrink-0">
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          <div className="p-1.5 sm:p-2 rounded-xl bg-primary/10 text-primary shrink-0">
            <BrainIcon size={18} className="sm:w-[22px] sm:h-[22px]" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 sm:gap-2">
              <h1 className="text-base sm:text-2xl font-display font-bold truncate">FORGE Brain</h1>
              <span className="text-[9px] sm:text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-primary/10 text-primary border border-primary/20">
                Copilot
              </span>
            </div>
            <div className="hidden sm:flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
              <span>Optimistic Concurrency Control (OCC)</span>
              <span>•</span>
              <span>Reversible Mutations</span>
            </div>
          </div>
        </div>

        {/* Header Badges & Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          <div className="hidden sm:block">
            <AutonomyBadge 
              level={permissions.autonomyLevel} 
              onClick={() => setIsAutonomyModalOpen(true)}
            />
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            className="h-7 sm:h-8 text-xs gap-1 sm:gap-1.5 px-2 sm:px-3"
            onClick={handleNewThread}
          >
            <Plus size={13} /> <span className="hidden sm:inline">New Thread</span><span className="sm:hidden">New</span>
          </Button>
        </div>
      </header>

      {/* Main Chat & Copilot Canvas */}
      <Card className="flex-1 min-h-0 flex flex-col overflow-hidden bg-card/60 border-primary/20 shadow-lg rounded-2xl">
        {/* Active Thread Meta Strip */}
        <div className="px-2.5 py-1.5 sm:px-4 sm:py-2 bg-secondary/30 border-b border-border/40 flex items-center justify-between text-xs shrink-0">
          <div className="flex items-center gap-2 min-w-0">
            <div className="relative">
              <button 
                onClick={() => setShowThreadList(!showThreadList)}
                className="flex items-center gap-1 font-semibold text-foreground hover:text-primary transition-colors py-0.5 px-1.5 sm:py-1 sm:px-2 rounded-md hover:bg-secondary text-xs"
              >
                <MessageSquare size={12} className="text-primary shrink-0" />
                <span className="truncate max-w-[130px] sm:max-w-[280px]">
                  {activeThread?.title || 'Main Conversation'}
                </span>
                <ChevronDown size={12} className="text-muted-foreground shrink-0" />
              </button>

              {/* Thread Dropdown */}
              {showThreadList && (
                <div className="absolute left-0 top-full mt-1 w-64 bg-card border border-border rounded-xl shadow-xl z-30 p-2 space-y-1 animate-in fade-in">
                  <div className="flex items-center justify-between px-2 py-1 text-[11px] font-semibold text-muted-foreground">
                    <span>AI Threads ({threads.length})</span>
                    <button onClick={handleNewThread} className="text-primary hover:underline flex items-center gap-0.5">
                      <Plus size={12} /> New
                    </button>
                  </div>
                  <div className="max-h-48 overflow-y-auto space-y-1">
                    {threads.map(t => (
                      <div 
                        key={t.id}
                        onClick={() => {
                          setActiveThread(t);
                          setShowThreadList(false);
                        }}
                        className={cn(
                          "px-2.5 py-1.5 rounded-lg text-xs cursor-pointer transition-colors flex items-center justify-between",
                          activeThread?.id === t.id ? "bg-primary/10 text-primary font-semibold" : "hover:bg-secondary text-foreground"
                        )}
                      >
                        <span className="truncate">{t.title}</span>
                        <span className="text-[10px] text-muted-foreground">{t.messages.length} msgs</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {targetWorkout && (
              <div className="hidden md:flex items-center gap-1 text-muted-foreground">
                <span>• Target:</span>
                <span className="font-semibold text-foreground truncate max-w-[180px]">
                  {targetWorkout.title}
                </span>
                <OCCVersionBadge version={targetWorkout.version} />
              </div>
            )}
          </div>

          <button 
            onClick={() => setIsAutonomyModalOpen(true)}
            className="text-[11px] text-muted-foreground hover:text-primary flex items-center gap-1 shrink-0"
          >
            <Settings2 size={12} /> <span className="hidden sm:inline">Settings</span>
          </button>
        </div>

        {/* Message Stream */}
        <div className="flex-1 min-h-0 overflow-y-auto p-2.5 sm:p-4 space-y-3 sm:space-y-4 overscroll-contain">
          {activeThread?.messages.map((msg, i) => {
            const isUser = msg.role === 'user';
            const isSystem = msg.role === 'system';

            if (isSystem) {
              return (
                <div key={msg.id || i} className="flex justify-center my-2">
                  <div className="max-w-[90%] rounded-xl px-3 py-2 text-xs bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center gap-2">
                    <CheckCircle2 size={14} className="shrink-0" />
                    <span>{msg.content}</span>
                  </div>
                </div>
              );
            }

            return (
              <div key={msg.id || i} className={cn("flex flex-col gap-2", isUser ? "items-end" : "items-start")}>
                <div className={cn(
                  "max-w-[88%] md:max-w-[80%] rounded-2xl px-3.5 py-2.5 sm:px-4 sm:py-3 text-xs sm:text-sm leading-relaxed shadow-2xs",
                  isUser 
                    ? "bg-primary text-primary-foreground rounded-tr-xs" 
                    : "bg-secondary/70 text-secondary-foreground rounded-tl-xs border border-border/40"
                )}>
                  {msg.content}
                </div>

                {/* Embedded Proposal Diff Card */}
                {msg.proposal && (
                  <div className="w-full max-w-[95%] md:max-w-[85%] mt-1">
                    <ProposalDiffCard 
                      proposal={msg.proposal}
                      currentWorkout={workouts.find(w => w.id === msg.proposal?.targetEntityId)}
                      onApprove={handleApproveProposal}
                      onDiscard={handleDiscardProposal}
                      onRebase={handleRebaseProposal}
                    />
                  </div>
                )}
              </div>
            );
          })}

          {/* Real-time Tool Status Indicator */}
          {loading && (
            <div className="flex justify-start">
              <div className="max-w-[85%] sm:max-w-[80%] rounded-2xl px-3 py-2 sm:px-4 sm:py-3 text-xs bg-secondary/80 text-secondary-foreground rounded-tl-xs border border-primary/20 flex items-center gap-2 shadow-sm animate-pulse">
                <BrainIcon size={14} className="text-primary animate-spin shrink-0" />
                <span className="font-medium text-foreground">{toolStatus || "FORGE Brain is formulating proposal..."}</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Prompt Input & Suggestions */}
        <div className="p-2 sm:p-3 md:p-4 border-t border-border bg-background/90 backdrop-blur-sm space-y-2 sm:space-y-3 shrink-0">
          {/* Quick Prompts Bar */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 no-scrollbar">
            {quickPrompts.map((qp, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(qp.text)}
                disabled={loading}
                className="whitespace-nowrap px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-lg text-[11px] sm:text-xs font-medium bg-secondary/60 hover:bg-secondary text-foreground border border-border/50 transition-colors shrink-0 flex items-center gap-1"
              >
                <span>{qp.label}</span>
              </button>
            ))}
          </div>

          <div className="flex gap-1.5 sm:gap-2">
            <Input 
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && !e.shiftKey && handleSend()}
              placeholder="Ask FORGE Brain to optimize..."
              disabled={loading}
              className="flex-1 bg-secondary/40 border-secondary focus:bg-background text-xs sm:text-sm h-9 sm:h-10"
            />
            <Button 
              size="icon" 
              onClick={() => handleSend()} 
              disabled={loading || !input.trim()}
              className="h-9 w-9 sm:h-10 sm:w-10 shrink-0 font-bold shadow-sm"
            >
              <Send size={15} />
            </Button>
          </div>
        </div>
      </Card>

      {/* Autonomy Modal */}
      <AutonomyModal 
        isOpen={isAutonomyModalOpen}
        onClose={() => setIsAutonomyModalOpen(false)}
        permissions={permissions}
        onUpdateAutonomy={handleUpdateAutonomy}
      />
    </div>
  );
}
