import React, { useState, useEffect } from 'react';
import { Proposal, Workout } from '../types';
import { useAuthStore } from '../store/useAuthStore';
import { 
  getProposals, 
  getWorkouts, 
  executeProposal, 
  discardProposal 
} from '../lib/api';
import { ProposalDiffCard } from '../components/ProposalDiffCard';
import { Button } from '../components/ui/Button';
import { Card, CardContent } from '../components/ui/Card';
import { 
  Sparkles, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  XCircle, 
  Layers, 
  ArrowRight,
  Brain
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { cn } from '../lib/utils';

export default function Proposals() {
  const { user } = useAuthStore();
  const navigate = useNavigate();

  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [workouts, setWorkouts] = useState<Workout[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>('ALL');

  const fetchData = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const pList = await getProposals(user.uid);
      const wList = await getWorkouts(user.uid);
      setProposals(pList);
      setWorkouts(wList);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [user]);

  const handleApprove = async (proposalId: string) => {
    if (!user) return;
    const res = await executeProposal(proposalId, user.uid, 'USER');
    if (res.success) {
      await fetchData();
    } else {
      throw new Error(res.error || "Failed to execute proposal");
    }
  };

  const handleDiscard = async (proposalId: string) => {
    if (!user) return;
    await discardProposal(proposalId, user.uid);
    await fetchData();
  };

  const handleRebase = (proposal: Proposal) => {
    navigate('/brain', { state: { targetWorkoutId: proposal.targetEntityId } });
  };

  const filteredProposals = proposals.filter(p => {
    if (filter === 'ALL') return true;
    return p.status === filter;
  });

  const pendingCount = proposals.filter(p => p.status === 'PENDING_APPROVAL').length;
  const conflictCount = proposals.filter(p => p.status === 'REJECTED_CONFLICT').length;

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-12">
      {/* Header */}
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl md:text-3xl font-display font-bold">Proposals & Review</h1>
            {pendingCount > 0 && (
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-primary text-primary-foreground">
                {pendingCount} Pending
              </span>
            )}
          </div>
          <p className="text-muted-foreground text-sm mt-1">
            Review, approve, or discard AI-generated workout recommendations before anything is committed to your data.
          </p>
        </div>

        <Button 
          onClick={() => navigate('/brain')}
          className="text-xs font-semibold gap-1.5 shrink-0"
        >
          <Brain size={15} /> Ask Brain for Proposals
        </Button>
      </header>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-border text-xs">
        {[
          { id: 'ALL', label: `All Proposals (${proposals.length})` },
          { id: 'PENDING_APPROVAL', label: `Pending Approval (${pendingCount})` },
          { id: 'EXECUTED', label: `Executed (${proposals.filter(p => p.status === 'EXECUTED').length})` },
          { id: 'REJECTED_CONFLICT', label: `Conflicts (${conflictCount})` },
          { id: 'DISCARDED', label: `Discarded (${proposals.filter(p => p.status === 'DISCARDED').length})` }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setFilter(tab.id)}
            className={cn(
              "px-3 py-1.5 rounded-lg font-semibold transition-colors whitespace-nowrap",
              filter === tab.id 
                ? "bg-primary text-primary-foreground" 
                : "text-muted-foreground hover:bg-secondary"
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Proposals Stream */}
      {loading ? (
        <div className="text-center py-16 text-muted-foreground text-sm">
          Loading proposals...
        </div>
      ) : filteredProposals.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground space-y-3 bg-secondary/10 rounded-2xl border border-dashed border-border p-8">
          <Sparkles size={36} className="mx-auto opacity-30 text-primary" />
          <h3 className="font-semibold text-base text-foreground">No proposals found</h3>
          <p className="text-xs max-w-sm mx-auto">
            When FORGE Brain recommends progressive overload or adjustments, its structured diff proposals will appear here for your approval.
          </p>
          <Button size="sm" onClick={() => navigate('/brain')}>
            Chat with FORGE Brain
          </Button>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredProposals.map(proposal => {
            const targetWorkout = workouts.find(w => w.id === proposal.targetEntityId);

            return (
              <ProposalDiffCard 
                key={proposal.id}
                proposal={proposal}
                currentWorkout={targetWorkout}
                onApprove={handleApprove}
                onDiscard={handleDiscard}
                onRebase={handleRebase}
              />
            );
          })}
        </div>
      )}
    </div>
  );
}
