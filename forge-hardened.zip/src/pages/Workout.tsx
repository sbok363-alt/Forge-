import React, { useState, useEffect } from 'react';
import { Workout, WorkoutSetItem } from '../types';
import { useAuthStore } from '../store/useAuthStore';
import { 
  getWorkouts, 
  saveWorkout, 
  seedForgeData 
} from '../lib/api';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { OCCVersionBadge } from '../components/OCCVersionBadge';
import { WorkoutDetailModal } from '../components/WorkoutDetailModal';
import { MutationAuditModal } from '../components/MutationAuditModal';
import { 
  Dumbbell, 
  Plus, 
  Calendar, 
  Sparkles, 
  History, 
  Play, 
  CheckCircle2, 
  Clock, 
  Flame,
  ArrowRight,
  Layers,
  ChevronRight
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { cn } from '../lib/utils';

export default function WorkoutPage() {
  const { user } = useAuthStore();
  const navigate = useNavigate();

  const [workouts, setWorkouts] = useState<Workout[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedWorkout, setSelectedWorkout] = useState<Workout | null>(null);
  const [auditTargetWorkout, setAuditTargetWorkout] = useState<Workout | null>(null);
  const [filter, setFilter] = useState<'ALL' | 'PLANNED' | 'COMPLETED'>('ALL');
  const [creating, setCreating] = useState(false);

  const fetchWorkoutsList = async () => {
    if (!user) return;
    setLoading(true);
    try {
      let data = await getWorkouts(user.uid);
      if (data.length === 0) {
        await seedForgeData(user.uid);
        data = await getWorkouts(user.uid);
      }
      setWorkouts(data);
    } catch (e) {
      console.error("Error fetching workouts:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWorkoutsList();
  }, [user]);

  const handleCreateEmptyWorkout = async () => {
    if (!user) return;
    const todayStr = new Date().toISOString().split('T')[0];
    const newW: Workout = {
      id: crypto.randomUUID(),
      userId: user.uid,
      title: `Workout Session #${workouts.length + 1}`,
      scheduledDate: todayStr,
      status: 'PLANNED',
      version: 1,
      sets: [
        { id: crypto.randomUUID(), exercise: 'Barbell Bench Press', reps: 10, weight: 60, completed: false },
        { id: crypto.randomUUID(), exercise: 'Barbell Bench Press', reps: 10, weight: 60, completed: false },
        { id: crypto.randomUUID(), exercise: 'Barbell Bent Over Row', reps: 10, weight: 60, completed: false }
      ],
      updatedAt: new Date().toISOString()
    };

    try {
      const saved = await saveWorkout(newW, 'USER', `Created new workout: ${newW.title}`);
      setWorkouts(prev => [saved, ...prev]);
      setSelectedWorkout(saved);
    } catch (e) {
      console.error("Failed to create workout:", e);
      alert("Failed to create workout. Please check your connection and try again.");
    }
  };

  const handleOpenBrainForWorkout = (workout: Workout) => {
    navigate('/brain', { 
      state: { 
        targetWorkoutId: workout.id,
        autoPrompt: `Please analyze and optimize this workout: "${workout.title}". Suggest progressive overload adjustments, set volume, and exercise sequence.`
      } 
    });
  };

  const filteredWorkouts = workouts.filter(w => {
    if (filter === 'ALL') return true;
    return w.status === filter;
  });

  const getStatusBadge = (status: Workout['status']) => {
    switch (status) {
      case 'IN_PROGRESS':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/20">
            <Clock size={11} /> In Progress
          </span>
        );
      case 'COMPLETED':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
            <CheckCircle2 size={11} /> Completed
          </span>
        );
      case 'SKIPPED':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
            Skipped
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-primary/10 text-primary border border-primary/20">
            <Calendar size={11} /> Planned
          </span>
        );
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-12">
      {/* Page Header */}
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-display font-bold">Workouts & Schedules</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Optimistic Concurrency Control (OCC) enabled. AI changes are proposed before writing.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={async () => {
              if (!user) return;
              await seedForgeData(user.uid);
              await fetchWorkoutsList();
            }}
            className="text-xs"
          >
            Reset Demo Data
          </Button>
          <Button 
            size="sm"
            onClick={handleCreateEmptyWorkout}
            className="text-xs font-semibold gap-1.5"
          >
            <Plus size={15} /> New Workout
          </Button>
        </div>
      </header>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 border-b border-border pb-2">
        <button
          onClick={() => setFilter('ALL')}
          className={cn(
            "px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors",
            filter === 'ALL' ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-secondary"
          )}
        >
          All Workouts ({workouts.length})
        </button>
        <button
          onClick={() => setFilter('PLANNED')}
          className={cn(
            "px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors",
            filter === 'PLANNED' ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-secondary"
          )}
        >
          Planned ({workouts.filter(w => w.status === 'PLANNED').length})
        </button>
        <button
          onClick={() => setFilter('COMPLETED')}
          className={cn(
            "px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors",
            filter === 'COMPLETED' ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-secondary"
          )}
        >
          Completed ({workouts.filter(w => w.status === 'COMPLETED').length})
        </button>
      </div>

      {/* Workouts Grid / List */}
      {loading ? (
        <div className="text-center py-16 text-muted-foreground text-sm">
          Loading OCC-synchronized workouts...
        </div>
      ) : filteredWorkouts.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground space-y-3 bg-secondary/10 rounded-2xl border border-dashed border-border p-8">
          <Dumbbell size={40} className="mx-auto opacity-30 text-primary" />
          <h3 className="font-semibold text-base text-foreground">No workouts found</h3>
          <p className="text-xs max-w-sm mx-auto">
            Create a custom workout or ask FORGE Brain to construct a progressive overload routine for you.
          </p>
          <Button size="sm" onClick={handleCreateEmptyWorkout}>
            Create First Workout
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredWorkouts.map((workout) => {
            // Group exercises for concise summary
            const uniqueExercises = Array.from(new Set((workout.sets || []).map(s => s.exercise)));
            const totalVolume = (workout.sets || []).reduce((sum, s) => sum + (s.weight * s.reps), 0);

            return (
              <Card 
                key={workout.id}
                className="overflow-hidden border border-border/70 hover:border-primary/50 transition-all shadow-sm hover:shadow-md flex flex-col justify-between"
              >
                <div>
                  {/* Card Header */}
                  <CardHeader className="p-4 bg-card border-b border-border/40 pb-3 flex flex-row items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <CardTitle className="text-lg font-bold truncate">
                          {workout.title}
                        </CardTitle>
                      </div>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1.5 font-medium">
                        <Calendar size={12} className="text-primary" />
                        <span>{workout.scheduledDate}</span>
                        <span>•</span>
                        <span>{workout.sets?.length || 0} sets</span>
                        <span>•</span>
                        <span>{Math.round(totalVolume)} kg</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {getStatusBadge(workout.status)}
                      <button 
                        className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-secondary rounded-md ml-1"
                        onClick={() => setSelectedWorkout(workout)}
                      >
                         <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
                      </button>
                    </div>
                  </CardHeader>

                  {/* Card Content */}
                  <CardContent className="p-4 space-y-3">
                    {/* Exercise List */}
                    <div className="space-y-1">
                       {uniqueExercises.slice(0, 3).map((ex, i) => {
                          const count = workout.sets.filter(s => s.exercise === ex).length;
                          return (
                            <div key={i} className="text-sm text-foreground/90 font-medium flex justify-between items-center py-0.5">
                              <span className="truncate pr-4">{ex}</span>
                              <span className="text-muted-foreground text-xs whitespace-nowrap">{count} sets</span>
                            </div>
                          );
                       })}
                       {uniqueExercises.length > 3 && (
                          <div className="text-xs text-muted-foreground italic mt-1">
                            +{uniqueExercises.length - 3} more exercises
                          </div>
                       )}
                    </div>
                  </CardContent>
                </div>

                {/* Card Actions */}
                <div className="p-3 bg-card border-t border-border/40">
                  {workout.status === 'COMPLETED' ? (
                     <Button 
                       variant="secondary" 
                       className="w-full font-bold h-11 text-xs"
                       onClick={() => setSelectedWorkout(workout)}
                     >
                       View Summary
                     </Button>
                  ) : (
                    <div className="flex gap-2">
                      <Button 
                        variant="outline"
                        className="flex-1 font-semibold h-11 text-xs gap-1.5 border-primary/30 hover:bg-primary/10 text-primary"
                        onClick={() => {
                          setSelectedWorkout(workout);
                        }}
                      >
                        <Sparkles size={14} /> Optimize
                      </Button>
                      <Button 
                        className="flex-1 font-bold h-11 text-xs gap-1.5"
                        onClick={() => {
                          setSelectedWorkout(workout);
                        }}
                      >
                        <Play size={14} fill="currentColor" /> Start
                      </Button>
                    </div>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Workout Detail & Set Editor Modal */}
      {selectedWorkout && (
        <WorkoutDetailModal 
          workout={selectedWorkout}
          isOpen={!!selectedWorkout}
          onClose={() => setSelectedWorkout(null)}
          onSave={(updated) => {
            setWorkouts(prev => prev.map(w => w.id === updated.id ? updated : w));
            setSelectedWorkout(null);
          }}
          onOpenBrain={(w) => handleOpenBrainForWorkout(w)}
          onOpenAudit={(w) => setAuditTargetWorkout(w)}
        />
      )}

      {/* Mutation Audit & Undo Modal */}
      {auditTargetWorkout && user && (
        <MutationAuditModal 
          isOpen={!!auditTargetWorkout}
          onClose={() => setAuditTargetWorkout(null)}
          userId={user.uid}
          targetWorkout={auditTargetWorkout}
          onWorkoutRestored={(restored) => {
            setWorkouts(prev => prev.map(w => w.id === restored.id ? restored : w));
          }}
        />
      )}
    </div>
  );
}
